import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "@/components/admin/AuthProvider";
import { RequireAuth } from "@/components/admin/RequireAuth";
import { ThemeProvider } from "@/components/admin/ThemeProvider";
import { AdminLayout } from "@/components/admin/AdminLayout";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import Index from "./pages/Index";
import OurProjects from "./pages/OurProjects";
import ContactUs from "./pages/ContactUs";
import Partners from "./pages/Partners";
import Portfolio from "./pages/Portfolio";
import AboutUs from "./pages/AboutUs";
import NotFound from "./pages/NotFound";
import Login from "./pages/admin/Login";
import Dashboard from "./pages/admin/Dashboard";
import AdminPartners from "./pages/admin/Partners";
import AddPartner from "./pages/admin/AddPartner";
import Consultants from "./pages/admin/Consultants";
import AddConsultant from "./pages/admin/AddConsultant";
import About from "./pages/admin/About";
import MissionVision from "./pages/admin/MissionVision";
import Contact from "./pages/admin/Contact";
import Settings from "./pages/admin/Settings";
import SEO from "./pages/admin/SEO";

const queryClient = new QueryClient();

// Layout wrapper for public pages
const PublicLayout = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith('/admin');
  
  if (isAdminRoute) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen">
      {/* Sticky Header */}
      <div className="sticky top-0 z-50 bg-white shadow-sm">
        <Header />
      </div>
      
      {/* Main content with proper spacing for sticky header */}
      <main className="min-h-screen">
        {children}
      </main>
      
      <Footer />
    </div>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <PublicLayout>
              <Routes>
                {/* Public Routes */}
                <Route path="/" element={<Index />} />
                <Route path="/projects" element={<OurProjects />} />
                <Route path="/contact" element={<ContactUs />} />
                <Route path="/partners" element={<Partners />} />
                <Route path="/portfolio" element={<Portfolio />} />
                <Route path="/about" element={<AboutUs />} />
                
                {/* Admin Routes */}
                <Route path="/admin/login" element={<Login />} />
                <Route path="/admin" element={
                  <RequireAuth>
                    <AdminLayout />
                  </RequireAuth>
                }>
                  <Route index element={<Dashboard />} />
                  <Route path="partners" element={<AdminPartners />} />
                  <Route path="partners/new" element={<AddPartner />} />
                  <Route path="consultants" element={<Consultants />} />
                  <Route path="consultants/new" element={<AddConsultant />} />
                  <Route path="about" element={<About />} />
                  <Route path="mission-vision" element={<MissionVision />} />
                  <Route path="contact" element={<Contact />} />
                  <Route path="settings" element={<Settings />} />
                  <Route path="seo" element={<SEO />} />
                </Route>
                
                {/* Catch-all route */}
                <Route path="*" element={<NotFound />} />
              </Routes>
            </PublicLayout>
          </BrowserRouter>
        </TooltipProvider>
      </AuthProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
