import { Monitor, Users, UserCheck, Briefcase } from "lucide-react";

const ServicesSection = () => {
  const services = [
    {
      icon: Monitor,
      title: "Mission and vision",
      description: "Our commitment to excellence and innovation"
    },
    {
      icon: Briefcase,
      title: "Our projects",
      description: "Cutting-edge telecom solutions"
    },
    {
      icon: Users,
      title: "Meet our team",
      description: "Expert professionals dedicated to success"
    },
    {
      icon: UserCheck,
      title: "Careers with us",
      description: "Join our growing team of innovators"
    }
  ];

  return (
    <section className="py-16 bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div key={index} className="text-center group cursor-pointer">
                <div className="mb-4 flex justify-center">
                  <IconComponent className="w-12 h-12 text-loop-blue group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-lg font-semibold mb-2 group-hover:text-loop-blue transition-colors duration-300">
                  {service.title}
                </h3>
                <p className="text-gray-400 text-sm">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;