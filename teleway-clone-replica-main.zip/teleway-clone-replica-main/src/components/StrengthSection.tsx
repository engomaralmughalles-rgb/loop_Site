import { DollarSign, Users, Target, Building } from "lucide-react";

const StrengthSection = () => {
  const strengths = [
    {
      icon: DollarSign,
      title: "Strong Financial Position",
      description: "Teleway has sound Financial stability and capacity to capitalise any business opportunity."
    },
    {
      icon: Users,
      title: "Experienced and Professional Staff",
      description: "Teleway has highly skilled and experienced staff to manage and maximize sales."
    },
    {
      icon: Target,
      title: "Aggressive",
      description: "Teleway aggressive market penetration strategy gives a competitive edge over other distributors."
    },
    {
      icon: Building,
      title: "Other",
      description: "Some more factors which add to Teleway strengths are Regional Head offices and Regional Warehouses."
    }
  ];

  return (
    <section className="py-16 bg-gray-900 text-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Teleway Strength</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {strengths.map((strength, index) => {
            const IconComponent = strength.icon;
            return (
              <div key={index} className="group">
                <div className="flex items-start space-x-4 p-6 rounded-lg hover:bg-gray-800 transition-colors duration-300">
                  <div className="flex-shrink-0">
                    <IconComponent className="w-12 h-12 text-loop-blue group-hover:text-white transition-colors duration-300" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-3 group-hover:text-loop-blue transition-colors duration-300">
                      {strength.title}
                    </h3>
                    <p className="text-gray-400 leading-relaxed">
                      {strength.description}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <div className="bg-gray-800 rounded-xl p-8">
            <h3 className="text-2xl font-bold mb-4">Advisers & Consultants</h3>
            <p className="text-gray-400 mb-8 max-w-3xl mx-auto">
              In Teleway the panel of advisers and consultants are keen to counsel our clients on their key strategic issues, leveraging our deep industry expertise and using analytical rigor to help them make informed decisions more quickly.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="w-32 h-32 bg-gradient-to-br from-teleway-blue to-blue-800 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                  M.A
                </div>
                <h4 className="text-lg font-semibold">Engr. Mansour Al-Obaid</h4>
                <p className="text-gray-400">Group Consultant</p>
              </div>
              
              <div className="text-center">
                <div className="w-32 h-32 bg-gradient-to-br from-green-600 to-green-800 rounded-full mx-auto mb-4 flex items-center justify-center text-white font-bold text-xl">
                  B.S
                </div>
                <h4 className="text-lg font-semibold">Bader Abdullah Bin Shaieg</h4>
                <p className="text-gray-400">Financial Advisory</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default StrengthSection;