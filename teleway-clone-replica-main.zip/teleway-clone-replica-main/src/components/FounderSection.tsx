import drAhmed from "@/assets/dr-ahmed.jpg";

const FounderSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="order-2 lg:order-1">
            <h3 className="text-3xl font-bold text-loop-dark mb-2">Dr. Ahmed Bin Fnais</h3>
            <h4 className="text-xl font-semibold text-loop-blue mb-6">Founder's Message</h4>
            
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
                After spending the past 15 years with Telecom Business, I feel very privileged to be writing this message as the Chief Executive Officer. This is a special time in our company's history as we celebrate the 15-year anniversary.
              </p>
              
              <p>
                We began our journey on Jan 1, 2005, and I have spent the past decade continuing to build our company, which has now become synonymous with our commitment in helping our clients share knowledge and create innovation. As a company, we have seen much change over the past 13 years. We have our workforce and have embraced diversity and gender balance. We have become the leading provider of working force based solutions in the kingdom. We have expanded our presence in different regions of the kingdom.
              </p>
              
              <p>
                It is also important to note what has not changed in Loop, namely our commitments to provide exceptional customer service and to live our core values.
              </p>
              
              <p>
                Excellence in everything, leadership by example, integrity and transparency focus on the client and employee centered. Looking ahead, we are focused on accelerating our growth. Strategy while continuing to build on the strength of our company ability–in helping our clients share knowledge and create innovation and in bringing positive change to the communities in which we work and live. I am incredibly excited about this journey and truly believe the best of Loop is yet to come.
              </p>
            </div>
          </div>
          
          <div className="order-1 lg:order-2 flex justify-center">
            <img 
              src={drAhmed} 
              alt="Dr. Ahmed Bin Fnais" 
              className="w-80 h-80 rounded-full object-cover shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default FounderSection;