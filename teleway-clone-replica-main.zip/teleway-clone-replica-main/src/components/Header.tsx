import { Phone, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";
import loopLogo from "@/assets/loop-logo.png";

const Header = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Add scroll effect
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      setIsScrolled(scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`w-full bg-white transition-shadow duration-300 ${isScrolled ? 'shadow-md' : 'shadow-sm'}`}>
      {/* Main navigation */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Phone numbers on the left */}
          <div className="flex items-center space-x-3">
            <Phone className="w-5 h-5 text-blue-600" />
            <div>
              <div className="text-xs text-gray-500 hidden sm:block">Have Any Questions?</div>
              <div className="text-sm font-medium text-blue-600">
                <a href="tel:+966114141413" className="hover:underline">011 414 1413</a>
                <span className="mx-1">-</span>
                <a href="tel:+966112220319" className="hover:underline">011 222 0319</a>
              </div>
            </div>
          </div>
          
          {/* Navigation in the center - Desktop */}
          <nav className="hidden lg:flex items-center justify-center flex-1" dir="ltr">
            <div className="flex items-center gap-8">
              <a href="/" className="text-gray-700 hover:text-gray-900 transition-colors font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-sm">
                Home
              </a>
              <div className="relative group">
                <a href="/about" className="text-gray-700 hover:text-gray-900 transition-colors font-medium flex items-center focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-sm">
                  About Us
                  <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </a>
              </div>
              <a href="/portfolio" className="text-gray-700 hover:text-gray-900 transition-colors font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-sm">
                Portfolio
              </a>
              <a href="/projects" className="text-gray-700 hover:text-gray-900 transition-colors font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-sm">
                Our Projects
              </a>
              <a href="/partners" className="text-gray-700 hover:text-gray-900 transition-colors font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-sm">
                Our Partners
              </a>
              <a href="/contact" className="text-gray-700 hover:text-gray-900 transition-colors font-medium focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 rounded-sm">
                Contact Us
              </a>
            </div>
          </nav>

          {/* Logo on the right in rounded circle */}
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full bg-white border border-gray-200 shadow-sm flex items-center justify-center p-2">
              <img src={loopLogo} alt="Loop" className="w-full h-full object-contain" />
            </div>
            
            {/* Mobile menu button */}
            <button
              onClick={toggleMobileMenu}
              className="lg:hidden p-2 rounded-md text-gray-700 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
              aria-label="Toggle navigation menu"
              aria-expanded={isMobileMenuOpen}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <nav className="lg:hidden mt-4 py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-3">
              <a
                href="/"
                className="text-gray-700 hover:text-gray-900 transition-colors font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Home
              </a>
              <a
                href="/about"
                className="text-gray-700 hover:text-gray-900 transition-colors font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About Us
              </a>
              <a
                href="/portfolio"
                className="text-gray-700 hover:text-gray-900 transition-colors font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Portfolio
              </a>
              <a
                href="/projects"
                className="text-gray-700 hover:text-gray-900 transition-colors font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Our Projects
              </a>
              <a
                href="/partners"
                className="text-gray-700 hover:text-gray-900 transition-colors font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Our Partners
              </a>
              <a
                href="/contact"
                className="text-gray-700 hover:text-gray-900 transition-colors font-medium py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Contact Us
              </a>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
};

export default Header;