import { useState } from "react";

const PartnersSection = () => {
  const [hoveredPartner, setHoveredPartner] = useState<string | null>(null);

  const partners = [
    {
      name: "STC",
      title: "Fiber Optics Sales",
      description: "STC Fiber Optics is the new home broadband service from STC.",
      color: "from-purple-600 to-purple-800"
    },
    {
      name: "Zain",
      title: "Cooperate Sales & Services",
      description: "Connectivity solutions to manage your business easily.",
      color: "from-green-600 to-green-800"
    },
    {
      name: "Mobily",
      title: "Sales & FTTH Installation",
      description: "Mobily Fiber Optics is the new home broadband service from Mobily.",
      color: "from-orange-600 to-orange-800"
    },
    {
      name: "Nokia",
      title: "FTTH Installation and Maintenance",
      description: "Nokia already powers the most powerful and reliable fiber networks in the world.",
      color: "from-blue-600 to-blue-800"
    },
    {
      name: "SALAM",
      title: "FTTH and 5G Personal Sales & Services",
      description: "FTTH & 5G higher performance and improved efficiency that 5G technology offers empower user experience.",
      color: "from-red-600 to-red-800"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-loop-dark mb-4">
            Our Partners
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            <strong>We Work With the Best Partners</strong> while we are at the forefront of and specialize in design-build, we are very familiar with a number of delivery methods and are confident we can find the process that will best help you meet your goals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {partners.map((partner, index) => (
            <div
              key={index}
              className="group cursor-pointer transform transition-all duration-300 hover:scale-105"
              onMouseEnter={() => setHoveredPartner(partner.name)}
              onMouseLeave={() => setHoveredPartner(null)}
            >
              <div className={`relative bg-gradient-to-br ${partner.color} rounded-xl p-8 text-white shadow-xl hover:shadow-2xl transition-all duration-300`}>
                <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 rounded-xl transition-opacity duration-300" />
                
                <div className="relative z-10">
                  <h3 className="text-2xl font-bold mb-2">{partner.name}</h3>
                  <h4 className="text-lg font-semibold mb-4 opacity-90">{partner.title}</h4>
                  <p className="text-sm opacity-80 leading-relaxed">
                    {partner.description}
                  </p>
                </div>
                
                {/* Hover effect overlay */}
                <div className={`absolute inset-0 bg-white opacity-0 group-hover:opacity-10 rounded-xl transition-opacity duration-300`} />
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default PartnersSection;