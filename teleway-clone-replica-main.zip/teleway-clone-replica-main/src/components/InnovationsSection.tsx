import { Button } from "@/components/ui/button";
import { Lightbulb, Target, Users, TrendingUp } from "lucide-react";

const InnovationsSection = () => {
  return (
    <section className="py-16 bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600">
      <div className="container mx-auto px-4 text-center text-white">
        <div className="mb-12">
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Innovations
          </h2>
          <p className="text-xl md:text-2xl max-w-4xl mx-auto leading-relaxed">
            Enchancing the telecom market and enabling and empowering of the Saudization to support the vision 2030
          </p>
        </div>
        
        {/* Floating Icons */}
        <div className="relative">
          <Lightbulb className="absolute top-0 left-10 w-12 h-12 text-white/30 animate-float" />
          <Target className="absolute top-10 right-10 w-10 h-10 text-white/25 animate-float-delayed" />
          <Users className="absolute bottom-0 left-20 w-14 h-14 text-white/20 animate-pulse-slow" />
          <TrendingUp className="absolute bottom-10 right-20 w-12 h-12 text-white/30 animate-float" />
        </div>
        
        <Button 
          className="bg-white text-loop-dark hover:bg-gray-100 px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 shadow-lg hover:shadow-xl mt-8"
        >
          Read More
        </Button>
      </div>
    </section>
  );
};

export default InnovationsSection;