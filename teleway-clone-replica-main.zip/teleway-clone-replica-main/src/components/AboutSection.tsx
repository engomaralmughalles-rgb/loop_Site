import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

const AboutSection = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-loop-dark mb-6">
            We Are The Largest Business Expert
          </h2>
          
          <div className="space-y-4 text-gray-600 leading-relaxed text-lg">
            <p>
              We believe in <strong className="text-loop-blue">Loop</strong> that distribution is the power of the existence of any product, so we are working on building a professional distribution team capable to work on any product or any project.
            </p>
            
            <p>
              We as <strong className="text-loop-blue">Loop</strong> partnering with the main telecom operators in Saudi Arabia to resale their products through our professional sales team who are working all regions of the Kingdom.
            </p>
            
            <div className="flex items-center justify-center space-x-2 my-6">
              <Phone className="w-5 h-5 text-loop-blue" />
              <span>For more information, kindly contact our customer service number </span>
              <a href="tel:+966114141413" className="text-loop-blue font-semibold hover:underline">
                011 414 1413
              </a>
            </div>
          </div>
          
          <Button 
            className="bg-loop-blue hover:bg-blue-600 text-white px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 shadow-lg hover:shadow-xl mt-6"
          >
            Read More
          </Button>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;