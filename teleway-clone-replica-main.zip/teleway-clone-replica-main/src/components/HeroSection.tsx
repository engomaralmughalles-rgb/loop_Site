import { Button } from "@/components/ui/button";
import { Wifi, Cloud } from "lucide-react";
import heroBg from "@/assets/hero-bg.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-[600px] flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroBg})` }}
      />
      
      {/* Gradient Overlay */}
      <div className="absolute inset-0 hero-gradient opacity-80" />
      
      {/* Floating Elements */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Cloud Icons */}
        <Cloud className="absolute top-20 left-20 w-16 h-16 text-white/30 animate-float" />
        <Cloud className="absolute top-32 right-32 w-20 h-20 text-white/20 animate-float-delayed" />
        <Cloud className="absolute bottom-32 left-1/4 w-12 h-12 text-white/25 animate-float" />
        
        {/* WiFi Icons */}
        <Wifi className="absolute top-40 right-20 w-14 h-14 text-white/30 animate-pulse-slow" />
        <Wifi className="absolute bottom-20 right-1/4 w-10 h-10 text-white/20 animate-pulse-slow" />
        
        {/* Additional decorative elements */}
        <div className="absolute top-1/4 left-1/3 w-32 h-32 border-2 border-white/10 rounded-full animate-pulse-slow" />
        <div className="absolute bottom-1/3 right-1/3 w-24 h-24 border border-white/15 rounded-full animate-float" />
      </div>
      
      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 text-center text-white">
        <h1 className="text-6xl md:text-8xl font-bold mb-6 text-shadow">
          Loop
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed text-shadow">
          Introducing the sales wings for the telecom operators to enhance the sales and proficient marketing.
        </p>
        <Button 
          variant="hero"
          size="lg"
        >
          Read More
        </Button>
      </div>
    </section>
  );
};

export default HeroSection;