import { Button } from "@/components/ui/button";

const Footer = () => {
  return (
    <footer className="bg-loop-dark text-white py-12">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold mb-4">We're Here To Help</h3>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Businesses today cross borders and regions, so you need a partner who can help you navigate the complexities of the telecom industry.
          </p>
          
          <Button 
            className="bg-loop-blue hover:bg-blue-600 text-white px-8 py-3 text-lg font-semibold rounded-full transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            Let's get started
          </Button>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center text-gray-400">
          <p>&copy; 2024 Loop. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;