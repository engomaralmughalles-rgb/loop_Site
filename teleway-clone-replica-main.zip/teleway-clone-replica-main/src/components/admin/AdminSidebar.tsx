import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard,
  Users,
  UserCheck,
  FileText,
  Target,
  Phone,
  Settings,
  LogOut,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useAuth } from '@/hooks/useAuth';

interface AdminSidebarProps {
  isCollapsed: boolean;
  isMobile: boolean;
  onClose: () => void;
}

const navigation = [
  {
    title: 'الرئيسية',
    items: [
      { name: 'لوحة التحكم', href: '/admin', icon: LayoutDashboard },
    ]
  },
  {
    title: 'إدارة المحتوى',
    items: [
      { name: 'الشركاء', href: '/admin/partners', icon: Users },
      { name: 'المستشارون', href: '/admin/consultants', icon: UserCheck },
      { name: 'حول تليواي', href: '/admin/about', icon: FileText },
      { name: 'الرؤية والرسالة', href: '/admin/mission-vision', icon: Target },
      { name: 'معلومات الاتصال', href: '/admin/contact', icon: Phone },
    ]
  },
  {
    title: 'الإعدادات',
    items: [
      { name: 'الإعدادات العامة', href: '/admin/settings', icon: Settings },
    ]
  }
];

export const AdminSidebar: React.FC<AdminSidebarProps> = ({ isCollapsed, isMobile, onClose }) => {
  const { logout, user } = useAuth();

  const handleLogout = async () => {
    await logout();
  };

  const getNavClasses = ({ isActive }: { isActive: boolean }) => 
    isActive 
      ? 'bg-sidebar-accent text-sidebar-accent-foreground font-medium' 
      : 'hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground';

  const NavigationItem = ({ item }: { item: typeof navigation[0]['items'][0] }) => {
    const content = (
      <NavLink 
        to={item.href} 
        end={item.href === '/admin'} 
        className={({ isActive }) => `
          flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
          ${getNavClasses({ isActive })}
          ${isCollapsed && !isMobile ? 'justify-center px-2' : 'justify-start'}
        `}
      >
        <item.icon className="w-5 h-5 shrink-0" />
        {(!isCollapsed || isMobile) && <span className="truncate">{item.name}</span>}
      </NavLink>
    );

    if (isCollapsed && !isMobile) {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              {content}
            </TooltipTrigger>
            <TooltipContent side="left" className="text-sm">
              {item.name}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    return content;
  };

  return (
    <div className="h-full bg-sidebar border-l border-sidebar-border flex flex-col shadow-lg">
      {/* Header */}
      <div className="border-b border-sidebar-border p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shrink-0">
              <span className="text-white font-bold text-sm">T</span>
            </div>
            {(!isCollapsed || isMobile) && (
              <div>
                <h2 className="font-bold text-sidebar-foreground">لوحة تحكم تليواي</h2>
                <p className="text-xs text-muted-foreground">نظام الإدارة</p>
              </div>
            )}
          </div>
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto py-4 px-2">
        {navigation.map((section) => (
          <div key={section.title} className="mb-6">
            {(!isCollapsed || isMobile) && (
              <div className="text-muted-foreground text-xs uppercase tracking-wider font-semibold px-3 mb-3">
                {section.title}
              </div>
            )}
            <div className="space-y-1">
              {section.items.map((item) => (
                <NavigationItem key={item.href} item={item} />
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="border-t border-sidebar-border p-4 space-y-4">
        {(!isCollapsed || isMobile) && user && (
          <>
            <div className="text-xs space-y-1">
              <p className="font-medium text-sidebar-foreground truncate">{user.name}</p>
              <p className="text-muted-foreground truncate">{user.email}</p>
            </div>
            <Separator />
          </>
        )}
        
        <Button
          variant="ghost" 
          size={(isCollapsed && !isMobile) ? "icon" : "sm"}
          onClick={handleLogout}
          className="w-full justify-start text-muted-foreground hover:text-destructive hover:bg-destructive/10"
        >
          <LogOut className={`w-4 h-4 ${(isCollapsed && !isMobile) ? '' : 'ml-2'}`} />
          {(!isCollapsed || isMobile) && 'تسجيل الخروج'}
        </Button>
      </div>
    </div>
  );
};