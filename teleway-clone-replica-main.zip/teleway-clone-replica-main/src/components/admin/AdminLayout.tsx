import React from 'react';
import { Outlet } from 'react-router-dom';
import { AdminSidebar } from './AdminSidebar';
import { AdminTopbar } from './AdminTopbar';
import { useSidebarState } from '@/hooks/useSidebarState';

export const AdminLayout: React.FC = () => {
  const { isCollapsed, isMobileOpen, toggleCollapsed, toggleMobile, closeMobile } = useSidebarState();
  const sidebarWidth = isCollapsed ? 72 : 300;

  return (
    <div className="min-h-screen w-full bg-background" dir="rtl">
      <div className="flex w-full min-h-screen">
        {/* Main Content Area */}
        <div className="flex-1 flex flex-col min-w-0" style={{ marginRight: `${sidebarWidth}px` }}>
          <AdminTopbar 
            onToggleSidebar={toggleCollapsed}
            onToggleMobile={toggleMobile}
            isCollapsed={isCollapsed}
          />
          
          <main className="flex-1 overflow-auto">
            <div className="container mx-auto p-6 max-w-7xl">
              <Outlet />
            </div>
          </main>
        </div>

        {/* Fixed Sidebar - Right Side (Desktop) */}
        <div 
          className="fixed top-0 right-0 h-full z-30 hidden lg:block transition-all duration-300 ease-in-out bg-sidebar border-l border-sidebar-border"
          style={{ width: `${sidebarWidth}px` }}
        >
          <AdminSidebar 
            isCollapsed={isCollapsed} 
            isMobile={false} 
            onClose={closeMobile}
          />
        </div>
      </div>
      
      {/* Mobile Sidebar Overlay */}
      {isMobileOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={closeMobile}
          />
          <div className="fixed inset-y-0 right-0 w-80 z-50 lg:hidden">
            <AdminSidebar 
              isCollapsed={false} 
              isMobile={true} 
              onClose={closeMobile}
            />
          </div>
        </>
      )}
    </div>
  );
};