import React, { useState } from 'react';
import { Search, Bell, Moon, Sun, Menu, Languages, ChevronRight, ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useTheme } from 'next-themes';

interface AdminTopbarProps {
  onSearch?: (query: string) => void;
  onToggleSidebar?: () => void;
  onToggleMobile?: () => void;
  isCollapsed?: boolean;
}

export const AdminTopbar: React.FC<AdminTopbarProps> = ({ 
  onSearch, 
  onToggleSidebar, 
  onToggleMobile, 
  isCollapsed = false 
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const { theme, setTheme } = useTheme();

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch?.(searchQuery);
  };

  const notifications = [
    { id: 1, title: 'شريك جديد تم إضافته', time: '5 دقائق', unread: true },
    { id: 2, title: 'تحديث معلومات الاتصال', time: '1 ساعة', unread: true },
    { id: 3, title: 'تم حذف مستشار', time: '2 ساعات', unread: false },
  ];

  const unreadCount = notifications.filter(n => n.unread).length;

  return (
    <header className="h-16 border-b border-border bg-card/50 backdrop-blur supports-[backdrop-filter]:bg-card/50" dir="rtl">
      <div className="h-full px-4 flex items-center justify-between gap-4">
        
        {/* Right Side - Sidebar Toggles & Search */}
        <div className="flex items-center gap-4 flex-1">
          {/* Mobile Toggle */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="lg:hidden text-muted-foreground hover:text-foreground"
            onClick={onToggleMobile}
          >
            <Menu className="w-4 h-4" />
          </Button>
          
          {/* Desktop Toggle */}
          <Button 
            variant="ghost" 
            size="icon" 
            className="hidden lg:flex text-muted-foreground hover:text-foreground"
            onClick={onToggleSidebar}
          >
            {isCollapsed ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </Button>
          
          <form onSubmit={handleSearchSubmit} className="relative max-w-md w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              type="text"
              placeholder="البحث في لوحة التحكم..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-background/50 border-border/50 focus:bg-background transition-colors text-right"
            />
          </form>
        </div>

        {/* Left Side - Actions */}
        <div className="flex items-center gap-2">
          
          {/* Language Toggle */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                <Languages className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem className="cursor-pointer">
                <span>العربية</span>
                <span className="ml-auto text-xs text-muted-foreground">الحالية</span>
              </DropdownMenuItem>
              <DropdownMenuItem className="cursor-pointer" disabled>
                <span>English</span>
                <span className="ml-auto text-xs text-muted-foreground">قريباً</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Theme Toggle */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
                <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-40">
              <DropdownMenuItem 
                onClick={() => setTheme("light")}
                className="cursor-pointer"
              >
                <Sun className="ml-2 h-4 w-4" />
                <span>فاتح</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => setTheme("dark")}
                className="cursor-pointer"
              >
                <Moon className="ml-2 h-4 w-4" />
                <span>داكن</span>
              </DropdownMenuItem>
              <DropdownMenuItem 
                onClick={() => setTheme("system")}
                className="cursor-pointer"
              >
                <Menu className="ml-2 h-4 w-4" />
                <span>النظام</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Notifications */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative text-muted-foreground hover:text-foreground">
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <Badge 
                    variant="destructive" 
                    className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 text-xs flex items-center justify-center"
                  >
                    {unreadCount}
                  </Badge>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80">
              <div className="p-3 border-b">
                <h4 className="font-medium text-sm">الإشعارات</h4>
                {unreadCount > 0 && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {unreadCount} إشعار جديد
                  </p>
                )}
              </div>
              
              <div className="max-h-80 overflow-y-auto">
                {notifications.map((notification) => (
                  <DropdownMenuItem key={notification.id} className="flex flex-col items-start p-3 cursor-pointer">
                    <div className="flex items-center gap-2 w-full">
                      <div className="flex-1">
                        <p className="text-sm font-medium">{notification.title}</p>
                        <p className="text-xs text-muted-foreground">{notification.time}</p>
                      </div>
                      {notification.unread && (
                        <div className="w-2 h-2 bg-primary rounded-full"></div>
                      )}
                    </div>
                  </DropdownMenuItem>
                ))}
              </div>
              
              <DropdownMenuSeparator />
              <div className="p-2">
                <Button variant="ghost" size="sm" className="w-full text-xs">
                  عرض جميع الإشعارات
                </Button>
              </div>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};