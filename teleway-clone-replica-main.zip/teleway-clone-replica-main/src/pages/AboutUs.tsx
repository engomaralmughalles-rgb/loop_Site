import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, Phone, Users, Globe, Award, Target } from "lucide-react";
import { useSEO } from "@/hooks/useSEO";

const AboutUs = () => {
  // SEO optimization
  useSEO({
    title: "About Us - Loop | Leading Telecommunications Company",
    description: "Learn about Loop, a leading telecommunications and technology company in Saudi Arabia. We provide advanced telecom solutions and high-quality technical services.",
    keywords: "About Loop, telecommunications company, technology, Saudi Arabia, telecom solutions, fiber optics",
    canonicalUrl: `${window.location.origin}/about`,
    ogUrl: window.location.href,
    structuredData: {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      "name": "About Us - Loop",
      "description": "Learn about Loop and its telecommunications and technology services",
      "url": `${window.location.origin}/about`,
      "inLanguage": "en",
      "isPartOf": {
        "@type": "WebSite",
        "name": "Loop",
        "url": window.location.origin
      }
    }
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=1887&auto=format&fit=crop')`,
          }}
        />
        <div className="relative container mx-auto px-4 text-left">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            About Us
          </h1>
          <nav className="flex justify-start items-center space-x-2 text-gray-300" dir="ltr">
            <a href="/" className="hover:text-white transition-colors">Home</a>
            <span>&gt;</span>
            <span className="text-white">About Us</span>
          </nav>
        </div>
      </section>

      {/* About Loop Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Text content on the left */}
            <div className="order-1">
              <div className="mb-8">
                <span className="text-blue-600 text-sm font-semibold uppercase tracking-wide">Who We Are?</span>
                <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mt-2 mb-6">
                  About Loop
                </h2>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  We are a team of passionate professionals dedicated to providing innovative telecom solutions and exceptional services. Our commitment to excellence and customer satisfaction drives everything we do.
                </p>
                <p className="text-gray-600 text-lg leading-relaxed mb-6">
                  With years of experience in the telecommunications industry, we have built a reputation for reliability, innovation, and quality service delivery across the Kingdom of Saudi Arabia.
                </p>
                <p className="text-gray-600 text-lg leading-relaxed">
                  Our comprehensive approach combines cutting-edge technology with deep industry expertise to deliver solutions that meet the evolving needs of our clients.
                </p>
              </div>
            </div>
            
            {/* Image on the right */}
            <div className="relative order-2">
              <img 
                src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=1887&auto=format&fit=crop" 
                alt="Loop team working on telecommunications infrastructure"
                className="rounded-xl shadow-2xl w-full h-96 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-600/20 to-transparent rounded-xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Telecom Industry</h3>
              <p className="text-gray-600">
                Comprehensive telecom solutions including fiber optics, 5G networks, and infrastructure development.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Phone className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Custom Solutions</h3>
              <p className="text-gray-600">
                Custom solutions tailored to meet your specific telecommunications and technology requirements.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Expert Team</h3>
              <p className="text-gray-600">
                Expert professionals with extensive experience in telecommunications and network infrastructure.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Mission & Vision</h3>
              <p className="text-gray-600">
                Driving digital transformation through innovative telecom solutions and exceptional service delivery.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission and Vision Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-12 text-left">Mission and Vision</h2>
            
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Mission */}
              <div className="bg-white rounded-xl p-8 shadow-lg">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mr-4">
                    <Target className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">Mission</h3>
                </div>
                <div className="space-y-4">
                  {[
                    "To provide cutting-edge telecommunications solutions that connect people and businesses",
                    "To deliver exceptional customer service and technical support",
                    "To foster innovation and technological advancement in the telecom sector",
                    "To contribute to the digital transformation of Saudi Arabia"
                  ].map((item, index) => (
                    <div key={index} className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0 mr-3" />
                      <span className="text-gray-600">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Vision */}
              <div className="bg-white rounded-xl p-8 shadow-lg">
                <div className="flex items-center mb-6">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                    <Award className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900">Vision</h3>
                </div>
                <div className="space-y-4">
                  {[
                    "To be the leading telecommunications solutions provider in the region",
                    "To drive digital innovation and connectivity across Saudi Arabia", 
                    "To set industry standards for quality and customer satisfaction",
                    "To expand our reach and impact in emerging markets"
                  ].map((item, index) => (
                    <div key={index} className="flex items-start">
                      <CheckCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0 mr-3" />
                      <span className="text-gray-600">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="text-left mt-12">
              <p className="text-gray-600 text-lg leading-relaxed max-w-4xl">
                Our mission and vision guide every aspect of our business, from the solutions we develop to the relationships we build with our clients and partners. We are committed to excellence in everything we do.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Work With Us?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Let's discuss how we can help you achieve your telecommunications goals with our innovative solutions.
          </p>
          <Button 
            variant="hero"
            size="lg"
          >
            Contact Us
          </Button>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;