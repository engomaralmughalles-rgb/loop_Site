import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Portfolio = () => {
  const portfolioItems = [
    {
      image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?q=80&w=1000&auto=format&fit=crop",
      title: "Mobily Fiber Optics",
      category: "Fiber Network Infrastructure"
    },
    {
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=1000&auto=format&fit=crop",
      title: "Mobily Fiber Optics",
      category: "Network Installation"
    },
    {
      image: "https://images.unsplash.com/photo-1581092918484-8313de4c1921?q=80&w=1000&auto=format&fit=crop",
      title: "Mobily Fiber Optics",
      category: "Maintenance Services"
    },
    {
      image: "https://images.unsplash.com/photo-1588196749597-9ff075ee6b5b?q=80&w=1000&auto=format&fit=crop",
      title: "Mobily Fiber Optics",
      category: "Network Operations"
    },
    {
      image: "https://images.unsplash.com/photo-1519452634265-7b70b95fac2c?q=80&w=1000&auto=format&fit=crop",
      title: "STC Fiber Optics",
      category: "Infrastructure Development"
    },
    {
      image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?q=80&w=1000&auto=format&fit=crop",
      title: "STC Fiber Optics",
      category: "Network Solutions"
    },
    {
      image: "https://images.unsplash.com/photo-1581092918484-8313de4c1921?q=80&w=1000&auto=format&fit=crop",
      title: "STC Fiber Optics",
      category: "Technical Support"
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-blue-50 to-gray-100">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1887&auto=format&fit=crop')`,
          }}
        />
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-teleway-dark mb-4">
            Portfolio
          </h1>
          <nav className="flex justify-center items-center space-x-2 text-teleway-gray">
            <a href="/" className="hover:text-teleway-blue transition-colors">Home</a>
            <span>›</span>
            <span className="text-teleway-blue">Portfolio</span>
          </nav>
        </div>
      </section>

      {/* Services Pie Chart Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Chart */}
            <div className="relative">
              <div className="w-80 h-80 mx-auto relative">
                {/* SVG Pie Chart */}
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 200 200">
                  <circle cx="100" cy="100" r="80" fill="#E74C3C" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="87.96 251.33" strokeDashoffset="0" />
                  <circle cx="100" cy="100" r="80" fill="#F39C12" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="69.12 251.33" strokeDashoffset="-87.96" />
                  <circle cx="100" cy="100" r="80" fill="#E67E22" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="62.83 251.33" strokeDashoffset="-157.08" />
                  <circle cx="100" cy="100" r="80" fill="#27AE60" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="50.27 251.33" strokeDashoffset="-219.91" />
                  <circle cx="100" cy="100" r="80" fill="#3498DB" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="43.98 251.33" strokeDashoffset="-270.18" />
                  <circle cx="100" cy="100" r="80" fill="#9B59B6" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="40.84 251.33" strokeDashoffset="-314.16" />
                  <circle cx="100" cy="100" r="80" fill="#95A5A6" stroke="#fff" strokeWidth="2" 
                    strokeDasharray="37.7 251.33" strokeDashoffset="-355" />
                </svg>
                
                {/* Center Logo */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-teleway-blue text-2xl font-bold">teleway</div>
                </div>
                
                {/* Labels */}
                <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-6">
                  <span className="bg-red-500 text-white px-3 py-1 rounded text-sm font-semibold">FTTH</span>
                </div>
                <div className="absolute top-1/4 right-0 transform translate-x-6">
                  <span className="bg-orange-500 text-white px-3 py-1 rounded text-sm font-semibold">Direct Sales</span>
                </div>
                <div className="absolute bottom-1/4 right-0 transform translate-x-6">
                  <span className="bg-yellow-500 text-white px-3 py-1 rounded text-sm font-semibold">Corporate Sales</span>
                </div>
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-6">
                  <span className="bg-green-500 text-white px-3 py-1 rounded text-sm font-semibold">Payment Solution</span>
                </div>
                <div className="absolute bottom-1/4 left-0 transform -translate-x-6">
                  <span className="bg-blue-500 text-white px-3 py-1 rounded text-sm font-semibold">Entertainment</span>
                </div>
                <div className="absolute top-1/4 left-0 transform -translate-x-6">
                  <span className="bg-gray-500 text-white px-3 py-1 rounded text-sm font-semibold">Civil Work</span>
                </div>
                <div className="absolute top-1/3 left-1/4 transform -translate-x-6 -translate-y-2">
                  <span className="bg-purple-500 text-white px-2 py-1 rounded text-xs font-semibold">Critical Communication</span>
                </div>
              </div>
            </div>

            {/* Content */}
            <div className="space-y-8">
              <div className="text-center lg:text-left">
                <span className="text-teleway-blue text-sm font-semibold uppercase tracking-wide">Business Channels</span>
                <h2 className="text-3xl md:text-4xl font-bold text-teleway-dark mt-2 mb-6">
                  Helping Businesses Channels
                </h2>
              </div>

              <div className="space-y-6">
                <p className="text-teleway-gray leading-relaxed">
                  <strong className="text-teleway-blue">We as Teleway</strong> partnering with the main telecom operators in Saudi Arabia to resale their products through our professional sales team who are working all regions of the Kingdom.
                </p>
                
                <p className="text-teleway-gray leading-relaxed">
                  We as Teleway partnering with the main telecom operators in Saudi Arabia to resale their products through our professional sales team who are working all regions of the Kingdom.
                </p>
                
                <p className="text-teleway-gray leading-relaxed">
                  In addition, we have expertise with areas of <strong className="text-teleway-blue">Civil Work</strong> <em>"Telecom towers supplies, installation and sites operation & maintenance including, Civil and Electromechanical"</em> and the <strong className="text-teleway-blue">Critical Communication</strong> <em>"HF/VHF Network Supply, Design, Coding and Maintenance of network elements"</em>.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Distribution Arms */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-teleway-dark mb-8">Distribution Arms</h2>
            <p className="text-teleway-gray text-lg leading-relaxed">
              We as Teleway partnering with the main telecom operators in Saudi Arabia to resale their products through our professional sales team who are working all regions of the Kingdom.
            </p>
          </div>
        </div>
      </section>

      {/* Client Relationships */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold text-teleway-dark mb-8 text-center">Clients Relationships</h2>
            <p className="text-teleway-gray text-lg leading-relaxed mb-12">
              The ground of our successful growth is the long-term relationship we build with our clients throughout the project lifecycle and subsequently. We set our customers' goals as ours and act accordingly aiming to enhance our customers business and profitability as well as market leadership. We keep monitoring our team performance and we keep developing the corporation environment with our clients in order to fulfill the client's requirements. We keep track the issues popped and log them in a professional way in order to be resolved efficiently. Teleway works as a business partner enabling its clients to select the right level of support, from simple advice up to a turnkey service that allows them to concentrate on developing their core business. We help our clients' to plan their solutions with quality and performance to meet their long-term business goals. We also help in planning end-user services and the systems to support them, by providing our clients with differentiation in the market place.
            </p>
          </div>
        </div>
      </section>

      {/* Portfolio Gallery */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {portfolioItems.map((item, index) => (
              <div key={index} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={item.image} 
                    alt={item.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-teleway-dark mb-2">{item.title}</h3>
                  <p className="text-teleway-gray text-sm">{item.category}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Help Section */}
      <section className="py-16 bg-teleway-blue text-white">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              We're Here To Help
            </h2>
            <p className="text-blue-100 text-lg mb-8">
              Businesses today cross borders and regions, so you need a service that goes where you are.
            </p>
            <Button 
              className="bg-white text-teleway-blue hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-full transition-all duration-300 shadow-lg hover:shadow-xl"
              onClick={() => window.location.href = '/contact'}
            >
              Get help here
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Portfolio;