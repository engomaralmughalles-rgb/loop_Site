import React, { useState } from 'react';
import { Save, Plus, Edit, Trash2, MapPin, Phone, Mail, Building, Globe, Facebook, Linkedin, Twitter, Instagram, Youtube } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';

interface SocialLink {
  id: string;
  platform: string;
  url: string;
  icon: string;
}

interface ContactInfo {
  address: {
    street: string;
    city: string;
    postalCode: string;
    country: string;
    mapUrl: string;
  };
  phones: string[];
  email: string;
  poBox: string;
  socialLinks: SocialLink[];
}

const socialPlatforms = [
  { value: 'facebook', label: 'Facebook', icon: Facebook },
  { value: 'linkedin', label: 'LinkedIn', icon: Linkedin },
  { value: 'twitter', label: 'Twitter', icon: Twitter },
  { value: 'instagram', label: 'Instagram', icon: Instagram },
  { value: 'youtube', label: 'YouTube', icon: Youtube },
];

const Contact: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('edit');
  const [socialDialog, setSocialDialog] = useState<{ open: boolean; editing?: SocialLink }>({ open: false });
  const [phoneDialog, setPhoneDialog] = useState<{ open: boolean; editing?: { index: number; phone: string } }>({ open: false });
  
  const [contactInfo, setContactInfo] = useState<ContactInfo>({
    address: {
      street: 'شارع العليا الرئيسي، المروج',
      city: 'الرياض',
      postalCode: '12281',
      country: 'المملكة العربية السعودية',
      mapUrl: 'https://maps.google.com/?q=Olaya+Main+Street+Al+Muruj+Riyadh',
    },
    phones: ['011 414 1413', '011 222 0319'],
    email: 'info@teleway.com.sa',
    poBox: 'الرياض - 12281',
    socialLinks: [
      {
        id: '1',
        platform: 'facebook',
        url: 'https://facebook.com/teleway',
        icon: 'facebook',
      },
      {
        id: '2',
        platform: 'linkedin',
        url: 'https://linkedin.com/company/teleway',
        icon: 'linkedin',
      },
      {
        id: '3',
        platform: 'twitter',
        url: 'https://twitter.com/teleway',
        icon: 'twitter',
      },
    ],
  });

  const [socialFormData, setSocialFormData] = useState({
    platform: '',
    url: '',
  });

  const [phoneFormData, setPhoneFormData] = useState('');

  const handleSave = () => {
    toast({
      title: "تم الحفظ بنجاح",
      description: "تم حفظ التحديثات على معلومات الاتصال",
    });
  };

  const handleAddSocial = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (socialDialog.editing) {
      // Update existing
      setContactInfo(prev => ({
        ...prev,
        socialLinks: prev.socialLinks.map(link =>
          link.id === socialDialog.editing!.id
            ? { ...link, platform: socialFormData.platform, url: socialFormData.url, icon: socialFormData.platform }
            : link
        ),
      }));
      toast({
        title: "تم التحديث",
        description: "تم تحديث الرابط الاجتماعي",
      });
    } else {
      // Add new
      const newLink: SocialLink = {
        id: Date.now().toString(),
        platform: socialFormData.platform,
        url: socialFormData.url,
        icon: socialFormData.platform,
      };
      setContactInfo(prev => ({
        ...prev,
        socialLinks: [...prev.socialLinks, newLink],
      }));
      toast({
        title: "تم الإضافة",
        description: "تم إضافة رابط اجتماعي جديد",
      });
    }
    
    setSocialDialog({ open: false });
    setSocialFormData({ platform: '', url: '' });
  };

  const handleAddPhone = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (phoneDialog.editing !== undefined) {
      // Update existing
      setContactInfo(prev => ({
        ...prev,
        phones: prev.phones.map((phone, index) =>
          index === phoneDialog.editing!.index ? phoneFormData : phone
        ),
      }));
      toast({
        title: "تم التحديث",
        description: "تم تحديث رقم الهاتف",
      });
    } else {
      // Add new
      setContactInfo(prev => ({
        ...prev,
        phones: [...prev.phones, phoneFormData],
      }));
      toast({
        title: "تم الإضافة",
        description: "تم إضافة رقم هاتف جديد",
      });
    }
    
    setPhoneDialog({ open: false });
    setPhoneFormData('');
  };

  const deleteSocialLink = (id: string) => {
    setContactInfo(prev => ({
      ...prev,
      socialLinks: prev.socialLinks.filter(link => link.id !== id),
    }));
    toast({
      title: "تم الحذف",
      description: "تم حذف الرابط الاجتماعي",
    });
  };

  const deletePhone = (index: number) => {
    setContactInfo(prev => ({
      ...prev,
      phones: prev.phones.filter((_, i) => i !== index),
    }));
    toast({
      title: "تم الحذف",
      description: "تم حذف رقم الهاتف",
    });
  };

  const openSocialDialog = (social?: SocialLink) => {
    if (social) {
      setSocialDialog({ open: true, editing: social });
      setSocialFormData({
        platform: social.platform,
        url: social.url,
      });
    } else {
      setSocialDialog({ open: true });
      setSocialFormData({ platform: '', url: '' });
    }
  };

  const openPhoneDialog = (phone?: string, index?: number) => {
    if (phone && index !== undefined) {
      setPhoneDialog({ open: true, editing: { index, phone } });
      setPhoneFormData(phone);
    } else {
      setPhoneDialog({ open: true });
      setPhoneFormData('');
    }
  };

  const getSocialIcon = (platform: string) => {
    const socialPlatform = socialPlatforms.find(p => p.value === platform);
    return socialPlatform ? socialPlatform.icon : Globe;
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة معلومات الاتصال</h1>
          <p className="text-muted-foreground mt-2">
            تحديث وإدارة بيانات الاتصال والتواصل
          </p>
        </div>
        <Button onClick={handleSave} className="gap-2">
          <Save className="w-4 h-4" />
          حفظ التغييرات
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="edit">تحرير المعلومات</TabsTrigger>
          <TabsTrigger value="preview">معاينة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="edit" className="space-y-6">
          {/* Address Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                معلومات العنوان
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>الشارع</Label>
                  <Input
                    value={contactInfo.address.street}
                    onChange={(e) => setContactInfo(prev => ({
                      ...prev,
                      address: { ...prev.address, street: e.target.value }
                    }))}
                    placeholder="اسم الشارع والحي"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>المدينة</Label>
                  <Input
                    value={contactInfo.address.city}
                    onChange={(e) => setContactInfo(prev => ({
                      ...prev,
                      address: { ...prev.address, city: e.target.value }
                    }))}
                    placeholder="اسم المدينة"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>الرمز البريدي</Label>
                  <Input
                    value={contactInfo.address.postalCode}
                    onChange={(e) => setContactInfo(prev => ({
                      ...prev,
                      address: { ...prev.address, postalCode: e.target.value }
                    }))}
                    placeholder="الرمز البريدي"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>الدولة</Label>
                  <Input
                    value={contactInfo.address.country}
                    onChange={(e) => setContactInfo(prev => ({
                      ...prev,
                      address: { ...prev.address, country: e.target.value }
                    }))}
                    placeholder="اسم الدولة"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>رابط الخريطة</Label>
                <Input
                  value={contactInfo.address.mapUrl}
                  onChange={(e) => setContactInfo(prev => ({
                    ...prev,
                    address: { ...prev.address, mapUrl: e.target.value }
                  }))}
                  placeholder="رابط Google Maps"
                />
              </div>
            </CardContent>
          </Card>

          {/* Contact Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Phone className="w-5 h-5" />
                تفاصيل الاتصال
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>البريد الإلكتروني</Label>
                <Input
                  type="email"
                  value={contactInfo.email}
                  onChange={(e) => setContactInfo(prev => ({ ...prev, email: e.target.value }))}
                  placeholder="البريد الإلكتروني الرئيسي"
                />
              </div>
              
              <div className="space-y-2">
                <Label>صندوق البريد</Label>
                <Input
                  value={contactInfo.poBox}
                  onChange={(e) => setContactInfo(prev => ({ ...prev, poBox: e.target.value }))}
                  placeholder="صندوق البريد"
                />
              </div>
              
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>أرقام الهاتف</Label>
                  <Button
                    onClick={() => openPhoneDialog()}
                    variant="outline"
                    size="sm"
                    className="gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    إضافة رقم
                  </Button>
                </div>
                <div className="space-y-2">
                  {contactInfo.phones.map((phone, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <span className="font-mono">{phone}</span>
                      <div className="flex items-center gap-1">
                        <Button
                          onClick={() => openPhoneDialog(phone, index)}
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          onClick={() => deletePhone(index)}
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Social Links */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  روابط التواصل الاجتماعي
                </CardTitle>
                <Button
                  onClick={() => openSocialDialog()}
                  variant="outline"
                  size="sm"
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  إضافة رابط
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                {contactInfo.socialLinks.map((social) => {
                  const Icon = getSocialIcon(social.platform);
                  const platform = socialPlatforms.find(p => p.value === social.platform);
                  
                  return (
                    <div key={social.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <Icon className="w-5 h-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{platform?.label || social.platform}</p>
                          <p className="text-sm text-muted-foreground truncate max-w-48">
                            {social.url}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          onClick={() => openSocialDialog(social)}
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8"
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          onClick={() => deleteSocialLink(social.id)}
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-center text-2xl">معلومات الاتصال</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                {/* Address Card */}
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">العنوان</h3>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p>{contactInfo.address.street}</p>
                    <p>{contactInfo.address.city} - {contactInfo.address.postalCode}</p>
                    <p>{contactInfo.address.country}</p>
                  </div>
                  <Button
                    variant="link"
                    size="sm"
                    className="mt-2 p-0 h-auto"
                    asChild
                  >
                    <a href={contactInfo.address.mapUrl} target="_blank" rel="noopener noreferrer">
                      عرض على الخريطة
                    </a>
                  </Button>
                </Card>

                {/* Phone Card */}
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Phone className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">الهاتف</h3>
                  <div className="text-sm text-muted-foreground space-y-1">
                    {contactInfo.phones.map((phone, index) => (
                      <div key={index}>
                        <a href={`tel:${phone.replace(/\s/g, '')}`} className="hover:text-primary">
                          {phone}
                        </a>
                      </div>
                    ))}
                  </div>
                </Card>

                {/* Email Card */}
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Mail className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">البريد الإلكتروني</h3>
                  <div className="text-sm text-muted-foreground">
                    <a href={`mailto:${contactInfo.email}`} className="hover:text-primary">
                      {contactInfo.email}
                    </a>
                  </div>
                </Card>

                {/* PO Box Card */}
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Building className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">صندوق البريد</h3>
                  <div className="text-sm text-muted-foreground">
                    <p>{contactInfo.poBox}</p>
                  </div>
                </Card>
              </div>

              {/* Social Links */}
              {contactInfo.socialLinks.length > 0 && (
                <div className="mt-8 text-center">
                  <h3 className="font-semibold mb-4">تابعونا على</h3>
                  <div className="flex justify-center gap-4">
                    {contactInfo.socialLinks.map((social) => {
                      const Icon = getSocialIcon(social.platform);
                      return (
                        <Button
                          key={social.id}
                          variant="outline"
                          size="icon"
                          className="w-10 h-10 rounded-full"
                          asChild
                        >
                          <a href={social.url} target="_blank" rel="noopener noreferrer">
                            <Icon className="w-5 h-5" />
                          </a>
                        </Button>
                      );
                    })}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Social Link Dialog */}
      <Dialog open={socialDialog.open} onOpenChange={(open) => setSocialDialog({ open })}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {socialDialog.editing ? 'تحديث الرابط الاجتماعي' : 'إضافة رابط اجتماعي جديد'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleAddSocial} className="space-y-4">
            <div className="space-y-2">
              <Label>المنصة</Label>
              <Select
                value={socialFormData.platform}
                onValueChange={(value) => setSocialFormData({...socialFormData, platform: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="اختر المنصة" />
                </SelectTrigger>
                <SelectContent>
                  {socialPlatforms.map((platform) => (
                    <SelectItem key={platform.value} value={platform.value}>
                      {platform.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label>الرابط</Label>
              <Input
                type="url"
                value={socialFormData.url}
                onChange={(e) => setSocialFormData({...socialFormData, url: e.target.value})}
                placeholder="https://..."
                required
              />
            </div>
            
            <div className="flex gap-2 pt-4">
              <Button type="submit" className="flex-1">
                {socialDialog.editing ? 'تحديث' : 'إضافة'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setSocialDialog({ open: false })}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Phone Dialog */}
      <Dialog open={phoneDialog.open} onOpenChange={(open) => setPhoneDialog({ open })}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {phoneDialog.editing ? 'تحديث رقم الهاتف' : 'إضافة رقم هاتف جديد'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleAddPhone} className="space-y-4">
            <div className="space-y-2">
              <Label>رقم الهاتف</Label>
              <Input
                type="tel"
                value={phoneFormData}
                onChange={(e) => setPhoneFormData(e.target.value)}
                placeholder="011 414 1413"
                required
              />
            </div>
            
            <div className="flex gap-2 pt-4">
              <Button type="submit" className="flex-1">
                {phoneDialog.editing ? 'تحديث' : 'إضافة'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setPhoneDialog({ open: false })}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Contact;