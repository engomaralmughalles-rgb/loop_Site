import React, { useState } from 'react';
import { Save, Plus, Edit, Trash2, Target, Eye, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';

interface MissionItem {
  id: string;
  title: string;
  description: string;
  order: number;
}

interface VisionItem {
  id: string;
  title: string;
  description: string;
  order: number;
}

interface MissionVisionContent {
  mission: {
    title: string;
    description: string;
    items: MissionItem[];
  };
  vision: {
    title: string;
    description: string;
    items: VisionItem[];
  };
}

const MissionVision: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('edit');
  const [editDialog, setEditDialog] = useState<{ open: boolean; type: 'mission' | 'vision' | null; item?: MissionItem | VisionItem }>({
    open: false,
    type: null,
  });
  
  const [content, setContent] = useState<MissionVisionContent>({
    mission: {
      title: 'رسالتنا',
      description: 'نسعى لتقديم حلول تقنية مبتكرة ومتطورة تساهم في تطوير الأعمال وتحقيق النجاح لعملائنا',
      items: [
        {
          id: '1',
          title: 'التميز التقني',
          description: 'تقديم أحدث الحلول التقنية والخدمات المتطورة في مجال الاتصالات',
          order: 1,
        },
        {
          id: '2',
          title: 'الشراكة الاستراتيجية',
          description: 'بناء شراكات قوية مع العملاء لضمان تحقيق أهدافهم التجارية',
          order: 2,
        },
        {
          id: '3',
          title: 'الابتكار المستمر',
          description: 'البحث والتطوير المستمر لتقديم حلول مبتكرة تواكب التطور التقني',
          order: 3,
        },
      ],
    },
    vision: {
      title: 'رؤيتنا',
      description: 'أن نكون الشركة الرائدة في تقديم الحلول التقنية المبتكرة في منطقة الشرق الأوسط',
      items: [
        {
          id: '1',
          title: 'الريادة الإقليمية',
          description: 'أن نصبح الشريك التقني الأول في منطقة الشرق الأوسط',
          order: 1,
        },
        {
          id: '2',
          title: 'التوسع العالمي',
          description: 'التوسع في الأسواق العالمية وتقديم خدماتنا على نطاق دولي',
          order: 2,
        },
        {
          id: '3',
          title: 'التأثير الإيجابي',
          description: 'المساهمة في التحول الرقمي وتطوير المجتمع التقني',
          order: 3,
        },
      ],
    },
  });

  const [formData, setFormData] = useState({
    title: '',
    description: '',
  });

  const handleSave = () => {
    toast({
      title: "تم الحفظ بنجاح",
      description: "تم حفظ التحديثات على الرؤية والرسالة",
    });
  };

  const openEditDialog = (type: 'mission' | 'vision', item?: MissionItem | VisionItem) => {
    setEditDialog({ open: true, type, item });
    if (item) {
      setFormData({
        title: item.title,
        description: item.description,
      });
    } else {
      setFormData({ title: '', description: '' });
    }
  };

  const handleSubmitItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editDialog.type) return;

    if (editDialog.item) {
      // Update existing item
      setContent(prev => ({
        ...prev,
        [editDialog.type!]: {
          ...prev[editDialog.type!],
          items: prev[editDialog.type!].items.map(item =>
            item.id === editDialog.item!.id
              ? { ...item, ...formData }
              : item
          ),
        },
      }));
      toast({
        title: "تم التحديث",
        description: "تم تحديث العنصر بنجاح",
      });
    } else {
      // Add new item
      const newItem = {
        id: Date.now().toString(),
        ...formData,
        order: content[editDialog.type].items.length + 1,
      };
      setContent(prev => ({
        ...prev,
        [editDialog.type!]: {
          ...prev[editDialog.type!],
          items: [...prev[editDialog.type!].items, newItem],
        },
      }));
      toast({
        title: "تم الإضافة",
        description: "تم إضافة عنصر جديد بنجاح",
      });
    }
    
    setEditDialog({ open: false, type: null });
    setFormData({ title: '', description: '' });
  };

  const deleteItem = (type: 'mission' | 'vision', itemId: string) => {
    setContent(prev => ({
      ...prev,
      [type]: {
        ...prev[type],
        items: prev[type].items.filter(item => item.id !== itemId),
      },
    }));
    toast({
      title: "تم الحذف",
      description: "تم حذف العنصر بنجاح",
    });
  };

  const updateMainContent = (type: 'mission' | 'vision', field: 'title' | 'description', value: string) => {
    setContent(prev => ({
      ...prev,
      [type]: {
        ...prev[type],
        [field]: value,
      },
    }));
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة الرؤية والرسالة</h1>
          <p className="text-muted-foreground mt-2">
            تحديث وإدارة محتوى الرؤية والرسالة للشركة
          </p>
        </div>
        <Button onClick={handleSave} className="gap-2">
          <Save className="w-4 h-4" />
          حفظ التغييرات
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="edit">تحرير المحتوى</TabsTrigger>
          <TabsTrigger value="preview">معاينة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="edit" className="space-y-6">
          {/* Mission Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                الرسالة
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>عنوان الرسالة</Label>
                <Input
                  value={content.mission.title}
                  onChange={(e) => updateMainContent('mission', 'title', e.target.value)}
                  placeholder="عنوان الرسالة"
                />
              </div>
              
              <div className="space-y-2">
                <Label>وصف الرسالة</Label>
                <Textarea
                  value={content.mission.description}
                  onChange={(e) => updateMainContent('mission', 'description', e.target.value)}
                  rows={3}
                  placeholder="وصف الرسالة"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label className="text-lg font-medium">عناصر الرسالة</Label>
                <Button
                  onClick={() => openEditDialog('mission')}
                  variant="outline"
                  size="sm"
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  إضافة عنصر
                </Button>
              </div>
              
              <div className="space-y-3">
                {content.mission.items.map((item, index) => (
                  <Card key={item.id} className="border-2 border-dashed">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="mt-1">
                          <GripVertical className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium mb-1">{item.title}</h4>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            onClick={() => openEditDialog('mission', item)}
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8"
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            onClick={() => deleteItem('mission', item.id)}
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Vision Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                الرؤية
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>عنوان الرؤية</Label>
                <Input
                  value={content.vision.title}
                  onChange={(e) => updateMainContent('vision', 'title', e.target.value)}
                  placeholder="عنوان الرؤية"
                />
              </div>
              
              <div className="space-y-2">
                <Label>وصف الرؤية</Label>
                <Textarea
                  value={content.vision.description}
                  onChange={(e) => updateMainContent('vision', 'description', e.target.value)}
                  rows={3}
                  placeholder="وصف الرؤية"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label className="text-lg font-medium">عناصر الرؤية</Label>
                <Button
                  onClick={() => openEditDialog('vision')}
                  variant="outline"
                  size="sm"
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  إضافة عنصر
                </Button>
              </div>
              
              <div className="space-y-3">
                {content.vision.items.map((item, index) => (
                  <Card key={item.id} className="border-2 border-dashed">
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="mt-1">
                          <GripVertical className="w-4 h-4 text-muted-foreground" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium mb-1">{item.title}</h4>
                          <p className="text-sm text-muted-foreground">{item.description}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            onClick={() => openEditDialog('vision', item)}
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8"
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button
                            onClick={() => deleteItem('vision', item.id)}
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-destructive hover:text-destructive"
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="preview" className="space-y-6">
          <div className="grid gap-8 md:grid-cols-2">
            {/* Mission Preview */}
            <Card className="h-fit">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">{content.mission.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center mb-6 leading-relaxed">
                  {content.mission.description}
                </p>
                <div className="space-y-4">
                  {content.mission.items.map((item, index) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                        {index + 1}
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">{item.title}</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Vision Preview */}
            <Card className="h-fit">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Eye className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-2xl">{content.vision.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center mb-6 leading-relaxed">
                  {content.vision.description}
                </p>
                <div className="space-y-4">
                  {content.vision.items.map((item, index) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-0.5">
                        {index + 1}
                      </div>
                      <div>
                        <h4 className="font-medium mb-1">{item.title}</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {item.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Dialog */}
      <Dialog open={editDialog.open} onOpenChange={(open) => setEditDialog({ open, type: null })}>
        <DialogContent className="max-w-md" dir="rtl">
          <DialogHeader>
            <DialogTitle>
              {editDialog.item ? 'تحديث العنصر' : `إضافة عنصر جديد في ${editDialog.type === 'mission' ? 'الرسالة' : 'الرؤية'}`}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmitItem} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">العنوان</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({...formData, title: e.target.value})}
                placeholder="عنوان العنصر"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">الوصف</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
                placeholder="وصف العنصر"
                rows={4}
                required
              />
            </div>
            
            <div className="flex gap-2 pt-4">
              <Button type="submit" className="flex-1">
                {editDialog.item ? 'تحديث' : 'إضافة'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setEditDialog({ open: false, type: null })}
                className="flex-1"
              >
                إلغاء
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MissionVision;