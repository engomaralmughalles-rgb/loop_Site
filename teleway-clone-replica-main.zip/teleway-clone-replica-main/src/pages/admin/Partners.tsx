import React, { useState } from 'react';
import { Plus, Search, Edit, Trash2, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';

interface Partner {
  id: string;
  name: string;
  description: string;
  logo: string;
  website: string;
  isActive: boolean;
  createdAt: Date;
}

const AdminPartners: React.FC = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingPartner, setEditingPartner] = useState<Partner | null>(null);
  
  const [partners, setPartners] = useState<Partner[]>([
    {
      id: '1',
      name: 'STC - شركة الاتصالات السعودية',
      description: 'الشريك الرئيسي في مجال الاتصالات',
      logo: '/placeholder.svg',
      website: 'https://stc.com.sa',
      isActive: true,
      createdAt: new Date('2024-01-15'),
    },
    {
      id: '2',
      name: 'زين السعودية',
      description: 'شريك استراتيجي في الحلول المتنقلة',
      logo: '/placeholder.svg',
      website: 'https://sa.zain.com',
      isActive: true,
      createdAt: new Date('2024-02-20'),
    },
    {
      id: '3',
      name: 'موبايلي',
      description: 'شراكة في تقنيات الاتصالات الحديثة',
      logo: '/placeholder.svg',
      website: 'https://mobily.com.sa',
      isActive: false,
      createdAt: new Date('2024-03-10'),
    },
  ]);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    website: '',
    isActive: true,
  });

  const filteredPartners = partners.filter(partner =>
    partner.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleEdit = (partner: Partner) => {
    setEditingPartner(partner);
    setFormData({
      name: partner.name,
      description: partner.description,
      website: partner.website,
      isActive: partner.isActive,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setPartners(partners.filter(p => p.id !== id));
    toast({
      title: "تم حذف الشريك",
      description: "تم حذف الشريك بنجاح",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingPartner) {
      setPartners(partners.map(p => 
        p.id === editingPartner.id 
          ? { ...p, ...formData }
          : p
      ));
      toast({
        title: "تم تحديث الشريك",
        description: "تم تحديث بيانات الشريك بنجاح",
      });
    } else {
      const newPartner: Partner = {
        id: Date.now().toString(),
        ...formData,
        logo: '/placeholder.svg',
        createdAt: new Date(),
      };
      setPartners([...partners, newPartner]);
      toast({
        title: "تم إضافة شريك جديد",
        description: "تم إضافة الشريك الجديد بنجاح",
      });
    }
    
    setIsDialogOpen(false);
    setEditingPartner(null);
    setFormData({ name: '', description: '', website: '', isActive: true });
  };

  const openCreateDialog = () => {
    setEditingPartner(null);
    setFormData({ name: '', description: '', website: '', isActive: true });
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة الشركاء</h1>
          <p className="text-muted-foreground mt-2">
            إدارة شركاء تليواي وعرض معلوماتهم
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog} className="gap-2">
              <Plus className="w-4 h-4" />
              إضافة شريك جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md" dir="rtl">
            <DialogHeader>
              <DialogTitle>
                {editingPartner ? 'تحديث بيانات الشريك' : 'إضافة شريك جديد'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">اسم الشريك</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="أدخل اسم الشريك"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">الوصف</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="أدخل وصف الشريك"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="website">الموقع الإلكتروني</Label>
                <Input
                  id="website"
                  type="url"
                  value={formData.website}
                  onChange={(e) => setFormData({...formData, website: e.target.value})}
                  placeholder="https://example.com"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="isActive">نشط</Label>
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({...formData, isActive: checked})}
                />
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1">
                  {editingPartner ? 'تحديث' : 'إضافة'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1"
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>قائمة الشركاء ({partners.length})</CardTitle>
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="البحث في الشركاء..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 text-right"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="text-right">الاسم</TableHead>
                <TableHead className="text-right">الوصف</TableHead>
                <TableHead className="text-right">الموقع الإلكتروني</TableHead>
                <TableHead className="text-right">الحالة</TableHead>
                <TableHead className="text-right">تاريخ الإضافة</TableHead>
                <TableHead className="text-right">الإجراءات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredPartners.map((partner) => (
                <TableRow key={partner.id}>
                  <TableCell className="font-medium">{partner.name}</TableCell>
                  <TableCell className="max-w-xs truncate">{partner.description}</TableCell>
                  <TableCell>
                    {partner.website && (
                      <a 
                        href={partner.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        زيارة الموقع
                      </a>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant={partner.isActive ? "default" : "secondary"}>
                      {partner.isActive ? 'نشط' : 'غير نشط'}
                    </Badge>
                  </TableCell>
                  <TableCell>{partner.createdAt.toLocaleDateString('ar-SA')}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleEdit(partner)}
                      >
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleDelete(partner.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          
          {filteredPartners.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              لا توجد نتائج للبحث "{searchQuery}"
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPartners;