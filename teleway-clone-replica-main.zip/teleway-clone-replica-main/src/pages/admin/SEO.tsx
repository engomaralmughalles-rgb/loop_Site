import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Globe, Target, Eye, Edit2, Save, Plus, Trash2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { SEOSettings, GlobalSEOSettings } from '@/types';

const SEO: React.FC = () => {
  const { toast } = useToast();
  const [seoPages, setSeoPages] = useState<SEOSettings[]>([]);
  const [globalSettings, setGlobalSettings] = useState<GlobalSEOSettings>({
    siteName: 'Loop',
    siteDescription: 'الشركة الرائدة في حلول الاتصالات بالمملكة العربية السعودية',
    defaultOgImage: '/loop-og-image.jpg',
    twitterHandle: '@loop_sa',
    robots: 'index, follow',
    updatedAt: new Date().toISOString()
  });
  const [selectedPage, setSelectedPage] = useState<SEOSettings | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Initialize with default pages
  useEffect(() => {
    const defaultPages: SEOSettings[] = [
      {
        id: '1',
        pageName: 'الصفحة الرئيسية',
        pageSlug: '/',
        title: 'Loop - الشركة الرائدة في حلول الاتصالات بالمملكة العربية السعودية',
        description: 'شركة لوب الرائدة في مجال حلول الاتصالات بالمملكة العربية السعودية. نقدم خدمات متطورة بالشراكة مع STC وزين وموبايلي ونوكيا وسلام.',
        keywords: 'لوب, اتصالات, STC, زين, موبايلي, نوكيا, سلام, السعودية, حلول الاتصالات',
        ogTitle: 'Loop - Leading Telecom Solutions in Saudi Arabia',
        ogDescription: 'لوب الرائدة في حلول الاتصالات بالمملكة العربية السعودية',
        ogImage: '/loop-og-image.jpg',
        twitterCard: 'summary_large_image',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '2',
        pageName: 'من نحن',
        pageSlug: '/about',
        title: 'من نحن - Loop | شركة الاتصالات الرائدة في المملكة',
        description: 'تعرف على رسالة ورؤية شركة لوب وفريق العمل المتخصص في مجال الاتصالات والتكنولوجيا بالمملكة العربية السعودية.',
        keywords: 'من نحن, لوب, رسالة الشركة, رؤية, فريق العمل, اتصالات السعودية',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '3',
        pageName: 'شركاؤنا',
        pageSlug: '/partners',
        title: 'شركاؤنا - Loop | شراكات استراتيجية في قطاع الاتصالات',
        description: 'شراكاتنا الاستراتيجية مع كبرى شركات الاتصالات: STC، زين، موبايلي، نوكيا، وسلام لتقديم أفضل الحلول التقنية.',
        keywords: 'شركاء لوب, STC, زين, موبايلي, نوكيا, سلام, شراكات اتصالات',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '4',
        pageName: 'مشاريعنا',
        pageSlug: '/projects',
        title: 'مشاريعنا - Loop | حلول مبتكرة في مجال الاتصالات',
        description: 'استعرض مشاريعنا المتطورة وحلولنا المبتكرة في مجال الاتصالات والتكنولوجيا لخدمة العملاء في المملكة العربية السعودية.',
        keywords: 'مشاريع لوب, حلول اتصالات, تكنولوجيا, مشاريع تقنية, السعودية',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      },
      {
        id: '5',
        pageName: 'تواصل معنا',
        pageSlug: '/contact',
        title: 'تواصل معنا - Loop | خدمة عملاء متميزة',
        description: 'تواصل مع فريق خدمة العملاء المتخصص في شركة لوب. نحن هنا لمساعدتك وتقديم أفضل الحلول التقنية.',
        keywords: 'تواصل معنا, خدمة عملاء لوب, دعم فني, استفسارات, اتصالات السعودية',
        isActive: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      }
    ];
    setSeoPages(defaultPages);
  }, []);

  const filteredPages = seoPages.filter(page =>
    page.pageName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    page.pageSlug.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSavePage = () => {
    if (!selectedPage) return;

    const updatedPages = seoPages.map(page =>
      page.id === selectedPage.id
        ? { ...selectedPage, updatedAt: new Date().toISOString() }
        : page
    );

    setSeoPages(updatedPages);
    setIsEditing(false);
    toast({
      title: 'تم حفظ إعدادات SEO',
      description: 'تم تحديث إعدادات محرك البحث بنجاح'
    });
  };

  const handleSaveGlobalSettings = () => {
    setGlobalSettings({
      ...globalSettings,
      updatedAt: new Date().toISOString()
    });

    toast({
      title: 'تم حفظ الإعدادات العامة',
      description: 'تم تحديث إعدادات SEO العامة بنجاح'
    });
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة محركات البحث (SEO)</h1>
          <p className="text-muted-foreground">
            إدارة إعدادات محركات البحث لتحسين ظهور الموقع
          </p>
        </div>
      </div>

      <Tabs defaultValue="pages" className="space-y-6">
        <TabsList className="grid w-fit grid-cols-2">
          <TabsTrigger value="pages" className="flex items-center gap-2">
            <Target className="w-4 h-4" />
            صفحات الموقع
          </TabsTrigger>
          <TabsTrigger value="global" className="flex items-center gap-2">
            <Globe className="w-4 h-4" />
            الإعدادات العامة
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pages" className="space-y-6">
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="البحث في الصفحات..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pages List */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  صفحات الموقع
                </CardTitle>
                <CardDescription>
                  اختر صفحة لتحرير إعدادات SEO الخاصة بها
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {filteredPages.map((page) => (
                  <div
                    key={page.id}
                    className={`p-4 rounded-lg border cursor-pointer transition-all hover:shadow-md ${
                      selectedPage?.id === page.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                    onClick={() => {
                      setSelectedPage(page);
                      setIsEditing(false);
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-foreground">{page.pageName}</h3>
                        <p className="text-sm text-muted-foreground">{page.pageSlug}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={page.isActive ? "default" : "secondary"}>
                          {page.isActive ? 'نشط' : 'غير نشط'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Page Editor */}
            {selectedPage && (
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2">
                      <Edit2 className="w-5 h-5" />
                      {selectedPage.pageName}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={selectedPage.isActive}
                        onCheckedChange={(checked) =>
                          setSelectedPage({ ...selectedPage, isActive: checked })
                        }
                      />
                      <Button
                        variant={isEditing ? "default" : "outline"}
                        size="sm"
                        onClick={() => setIsEditing(!isEditing)}
                      >
                        {isEditing ? 'إلغاء' : 'تحرير'}
                      </Button>
                    </div>
                  </div>
                  <CardDescription>
                    إعدادات SEO للصفحة: {selectedPage.pageSlug}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">عنوان الصفحة (Title)</Label>
                    <Input
                      id="title"
                      value={selectedPage.title}
                      onChange={(e) =>
                        setSelectedPage({ ...selectedPage, title: e.target.value })
                      }
                      disabled={!isEditing}
                      placeholder="عنوان الصفحة..."
                    />
                    <p className="text-xs text-muted-foreground">
                      الطول: {selectedPage.title.length} حرف (الأمثل: 50-60 حرف)
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">وصف الصفحة (Meta Description)</Label>
                    <Textarea
                      id="description"
                      value={selectedPage.description}
                      onChange={(e) =>
                        setSelectedPage({ ...selectedPage, description: e.target.value })
                      }
                      disabled={!isEditing}
                      placeholder="وصف الصفحة..."
                      rows={3}
                    />
                    <p className="text-xs text-muted-foreground">
                      الطول: {selectedPage.description.length} حرف (الأمثل: 150-160 حرف)
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="keywords">الكلمات المفتاحية</Label>
                    <Input
                      id="keywords"
                      value={selectedPage.keywords || ''}
                      onChange={(e) =>
                        setSelectedPage({ ...selectedPage, keywords: e.target.value })
                      }
                      disabled={!isEditing}
                      placeholder="الكلمات المفتاحية مفصولة بفواصل..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ogTitle">عنوان Open Graph</Label>
                    <Input
                      id="ogTitle"
                      value={selectedPage.ogTitle || ''}
                      onChange={(e) =>
                        setSelectedPage({ ...selectedPage, ogTitle: e.target.value })
                      }
                      disabled={!isEditing}
                      placeholder="عنوان للشبكات الاجتماعية..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ogDescription">وصف Open Graph</Label>
                    <Textarea
                      id="ogDescription"
                      value={selectedPage.ogDescription || ''}
                      onChange={(e) =>
                        setSelectedPage({ ...selectedPage, ogDescription: e.target.value })
                      }
                      disabled={!isEditing}
                      placeholder="وصف للشبكات الاجتماعية..."
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ogImage">صورة Open Graph</Label>
                    <Input
                      id="ogImage"
                      value={selectedPage.ogImage || ''}
                      onChange={(e) =>
                        setSelectedPage({ ...selectedPage, ogImage: e.target.value })
                      }
                      disabled={!isEditing}
                      placeholder="رابط الصورة..."
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="twitterCard">نوع بطاقة Twitter</Label>
                    <Select
                      value={selectedPage.twitterCard || 'summary_large_image'}
                      onValueChange={(value: 'summary' | 'summary_large_image') =>
                        setSelectedPage({ ...selectedPage, twitterCard: value })
                      }
                      disabled={!isEditing}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="summary">ملخص عادي</SelectItem>
                        <SelectItem value="summary_large_image">ملخص بصورة كبيرة</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {isEditing && (
                    <Button onClick={handleSavePage} className="w-full">
                      <Save className="w-4 h-4 ml-2" />
                      حفظ التغييرات
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="global" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                الإعدادات العامة لمحركات البحث
              </CardTitle>
              <CardDescription>
                إعدادات SEO العامة للموقع
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="siteName">اسم الموقع</Label>
                  <Input
                    id="siteName"
                    value={globalSettings.siteName}
                    onChange={(e) =>
                      setGlobalSettings({ ...globalSettings, siteName: e.target.value })
                    }
                    placeholder="اسم الموقع..."
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="twitterHandle">حساب Twitter</Label>
                  <Input
                    id="twitterHandle"
                    value={globalSettings.twitterHandle}
                    onChange={(e) =>
                      setGlobalSettings({ ...globalSettings, twitterHandle: e.target.value })
                    }
                    placeholder="@username"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="siteDescription">وصف الموقع العام</Label>
                <Textarea
                  id="siteDescription"
                  value={globalSettings.siteDescription}
                  onChange={(e) =>
                    setGlobalSettings({ ...globalSettings, siteDescription: e.target.value })
                  }
                  placeholder="وصف عام للموقع..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="defaultOgImage">الصورة الافتراضية لـ Open Graph</Label>
                <Input
                  id="defaultOgImage"
                  value={globalSettings.defaultOgImage}
                  onChange={(e) =>
                    setGlobalSettings({ ...globalSettings, defaultOgImage: e.target.value })
                  }
                  placeholder="رابط الصورة الافتراضية..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="robots">إعدادات Robots</Label>
                <Select
                  value={globalSettings.robots}
                  onValueChange={(value) =>
                    setGlobalSettings({ ...globalSettings, robots: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="index, follow">فهرسة ومتابعة الروابط</SelectItem>
                    <SelectItem value="noindex, nofollow">عدم الفهرسة وعدم متابعة الروابط</SelectItem>
                    <SelectItem value="index, nofollow">فهرسة بدون متابعة الروابط</SelectItem>
                    <SelectItem value="noindex, follow">عدم الفهرسة مع متابعة الروابط</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="googleAnalyticsId">Google Analytics ID</Label>
                  <Input
                    id="googleAnalyticsId"
                    value={globalSettings.googleAnalyticsId || ''}
                    onChange={(e) =>
                      setGlobalSettings({ ...globalSettings, googleAnalyticsId: e.target.value })
                    }
                    placeholder="G-XXXXXXXXXX"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="googleTagManagerId">Google Tag Manager ID</Label>
                  <Input
                    id="googleTagManagerId"
                    value={globalSettings.googleTagManagerId || ''}
                    onChange={(e) =>
                      setGlobalSettings({ ...globalSettings, googleTagManagerId: e.target.value })
                    }
                    placeholder="GTM-XXXXXXX"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="facebookPixelId">Facebook Pixel ID</Label>
                  <Input
                    id="facebookPixelId"
                    value={globalSettings.facebookPixelId || ''}
                    onChange={(e) =>
                      setGlobalSettings({ ...globalSettings, facebookPixelId: e.target.value })
                    }
                    placeholder="000000000000000"
                  />
                </div>
              </div>

              <Button onClick={handleSaveGlobalSettings} className="w-full">
                <Save className="w-4 h-4 ml-2" />
                حفظ الإعدادات العامة
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SEO;