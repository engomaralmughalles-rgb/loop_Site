import React, { useState } from 'react';
import { Save, Upload, Eye, Shield, Bell, User, Globe, Database, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

interface SystemSettings {
  siteName: string;
  siteDescription: string;
  logo: string;
  favicon: string;
  maintenanceMode: boolean;
  allowRegistration: boolean;
  emailNotifications: boolean;
  backupFrequency: string;
  language: string;
  timezone: string;
}

const Settings: React.FC = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('general');
  
  const [settings, setSettings] = useState<SystemSettings>({
    siteName: 'تليواي - لوحة التحكم',
    siteDescription: 'نظام إدارة محتوى موقع تليواي للحلول التقنية',
    logo: '/src/assets/teleway-logo.png',
    favicon: '/favicon.ico',
    maintenanceMode: false,
    allowRegistration: false,
    emailNotifications: true,
    backupFrequency: 'daily',
    language: 'ar',
    timezone: 'Asia/Riyadh',
  });

  const [userProfile, setUserProfile] = useState({
    name: user?.name || 'المدير العام',
    email: user?.email || 'admin@teleway.com.sa',
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleSaveSettings = () => {
    toast({
      title: "تم الحفظ بنجاح",
      description: "تم حفظ إعدادات النظام بنجاح",
    });
  };

  const handleSaveProfile = () => {
    if (userProfile.newPassword && userProfile.newPassword !== userProfile.confirmPassword) {
      toast({
        title: "خطأ في كلمة المرور",
        description: "كلمة المرور الجديدة غير متطابقة",
        variant: "destructive",
      });
      return;
    }
    
    toast({
      title: "تم التحديث",
      description: "تم تحديث ملف التعريف الشخصي بنجاح",
    });
    
    setUserProfile(prev => ({
      ...prev,
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    }));
  };

  const handleClearCache = () => {
    toast({
      title: "تم مسح التخزين المؤقت",
      description: "تم مسح جميع ملفات التخزين المؤقت بنجاح",
    });
  };

  const handleBackupData = () => {
    toast({
      title: "تم إنشاء النسخة الاحتياطية",
      description: "تم إنشاء نسخة احتياطية من البيانات بنجاح",
    });
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">الإعدادات العامة</h1>
          <p className="text-muted-foreground mt-2">
            إدارة إعدادات النظام والملف الشخصي
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="general">عام</TabsTrigger>
          <TabsTrigger value="profile">الملف الشخصي</TabsTrigger>
          <TabsTrigger value="security">الأمان</TabsTrigger>
          <TabsTrigger value="maintenance">الصيانة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                إعدادات الموقع
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>اسم الموقع</Label>
                  <Input
                    value={settings.siteName}
                    onChange={(e) => setSettings({...settings, siteName: e.target.value})}
                    placeholder="اسم الموقع"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>اللغة الافتراضية</Label>
                  <select
                    value={settings.language}
                    onChange={(e) => setSettings({...settings, language: e.target.value})}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="ar">العربية</option>
                    <option value="en">English</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label>المنطقة الزمنية</Label>
                  <select
                    value={settings.timezone}
                    onChange={(e) => setSettings({...settings, timezone: e.target.value})}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="Asia/Riyadh">الرياض (GMT+3)</option>
                    <option value="UTC">UTC</option>
                  </select>
                </div>
                
                <div className="space-y-2">
                  <Label>تكرار النسخ الاحتياطي</Label>
                  <select
                    value={settings.backupFrequency}
                    onChange={(e) => setSettings({...settings, backupFrequency: e.target.value})}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    <option value="daily">يومياً</option>
                    <option value="weekly">أسبوعياً</option>
                    <option value="monthly">شهرياً</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label>وصف الموقع</Label>
                <Textarea
                  value={settings.siteDescription}
                  onChange={(e) => setSettings({...settings, siteDescription: e.target.value})}
                  placeholder="وصف مختصر عن الموقع"
                  rows={3}
                />
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>شعار الموقع</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      value={settings.logo}
                      onChange={(e) => setSettings({...settings, logo: e.target.value})}
                      placeholder="رابط الشعار"
                    />
                    <Button variant="outline" size="icon">
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>أيقونة الموقع</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      value={settings.favicon}
                      onChange={(e) => setSettings({...settings, favicon: e.target.value})}
                      placeholder="رابط الأيقونة"
                    />
                    <Button variant="outline" size="icon">
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center justify-between pt-4">
                <div className="space-y-1">
                  <Label>الإشعارات عبر البريد الإلكتروني</Label>
                  <p className="text-sm text-muted-foreground">
                    إرسال إشعارات النظام عبر البريد الإلكتروني
                  </p>
                </div>
                <Switch
                  checked={settings.emailNotifications}
                  onCheckedChange={(checked) => setSettings({...settings, emailNotifications: checked})}
                />
              </div>
              
              <div className="pt-4">
                <Button onClick={handleSaveSettings} className="gap-2">
                  <Save className="w-4 h-4" />
                  حفظ الإعدادات
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="profile" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                المعلومات الشخصية
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>الاسم الكامل</Label>
                  <Input
                    value={userProfile.name}
                    onChange={(e) => setUserProfile({...userProfile, name: e.target.value})}
                    placeholder="الاسم الكامل"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>البريد الإلكتروني</Label>
                  <Input
                    type="email"
                    value={userProfile.email}
                    onChange={(e) => setUserProfile({...userProfile, email: e.target.value})}
                    placeholder="البريد الإلكتروني"
                  />
                </div>
              </div>
              
              <div className="pt-4">
                <Button onClick={handleSaveProfile} variant="outline" className="gap-2">
                  <Save className="w-4 h-4" />
                  حفظ المعلومات
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>تغيير كلمة المرور</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>كلمة المرور الحالية</Label>
                <Input
                  type="password"
                  value={userProfile.currentPassword}
                  onChange={(e) => setUserProfile({...userProfile, currentPassword: e.target.value})}
                  placeholder="كلمة المرور الحالية"
                />
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>كلمة المرور الجديدة</Label>
                  <Input
                    type="password"
                    value={userProfile.newPassword}
                    onChange={(e) => setUserProfile({...userProfile, newPassword: e.target.value})}
                    placeholder="كلمة المرور الجديدة"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>تأكيد كلمة المرور</Label>
                  <Input
                    type="password"
                    value={userProfile.confirmPassword}
                    onChange={(e) => setUserProfile({...userProfile, confirmPassword: e.target.value})}
                    placeholder="تأكيد كلمة المرور الجديدة"
                  />
                </div>
              </div>
              
              <div className="pt-4">
                <Button onClick={handleSaveProfile} className="gap-2">
                  <Shield className="w-4 h-4" />
                  تحديث كلمة المرور
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                إعدادات الأمان
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>السماح بالتسجيل الجديد</Label>
                  <p className="text-sm text-muted-foreground">
                    السماح للمستخدمين الجدد بإنشاء حسابات
                  </p>
                </div>
                <Switch
                  checked={settings.allowRegistration}
                  onCheckedChange={(checked) => setSettings({...settings, allowRegistration: checked})}
                />
              </div>
              
              <div className="pt-4 space-y-3">
                <h4 className="font-medium">جلسات تسجيل الدخول النشطة</h4>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">الجلسة الحالية</p>
                      <p className="text-sm text-muted-foreground">Chrome • الرياض، السعودية</p>
                    </div>
                    <Badge variant="default">نشط الآن</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="maintenance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Database className="w-5 h-5" />
                صيانة النظام
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label>وضع الصيانة</Label>
                  <p className="text-sm text-muted-foreground">
                    إيقاف الموقع مؤقتاً لأعمال الصيانة
                  </p>
                </div>
                <Switch
                  checked={settings.maintenanceMode}
                  onCheckedChange={(checked) => setSettings({...settings, maintenanceMode: checked})}
                />
              </div>
              
              <div className="grid gap-4 md:grid-cols-2">
                <Card className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Trash2 className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">مسح التخزين المؤقت</h4>
                      <p className="text-sm text-muted-foreground">مسح ملفات التخزين المؤقت</p>
                    </div>
                  </div>
                  <Button onClick={handleClearCache} variant="outline" size="sm" className="w-full">
                    مسح التخزين المؤقت
                  </Button>
                </Card>
                
                <Card className="p-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <Database className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">نسخة احتياطية</h4>
                      <p className="text-sm text-muted-foreground">إنشاء نسخة احتياطية من البيانات</p>
                    </div>
                  </div>
                  <Button onClick={handleBackupData} variant="outline" size="sm" className="w-full">
                    إنشاء نسخة احتياطية
                  </Button>
                </Card>
              </div>
              
              <Card className="border-destructive/20 bg-destructive/5">
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <Shield className="w-5 h-5 text-destructive mt-0.5" />
                    <div>
                      <h4 className="font-medium text-destructive mb-1">منطقة الخطر</h4>
                      <p className="text-sm text-muted-foreground mb-3">
                        العمليات التالية قد تؤثر على النظام بشكل دائم
                      </p>
                      <Button variant="destructive" size="sm">
                        إعادة تعيين النظام
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;