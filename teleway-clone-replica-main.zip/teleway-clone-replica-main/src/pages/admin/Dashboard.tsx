import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  UserCheck, 
  Activity, 
  Calendar,
  Plus,
  Eye,
  TrendingUp,
  Clock
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { mockApiService } from '@/services/mockApi';
import { DashboardStats, Partner, Consultant } from '@/types';
import { Skeleton } from '@/components/ui/skeleton';

const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentPartners, setRecentPartners] = useState<Partner[]>([]);
  const [recentConsultants, setRecentConsultants] = useState<Consultant[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadDashboardData = async () => {
      try {
        setIsLoading(true);
        
        // Load stats
        const statsResponse = await mockApiService.getDashboardStats();
        setStats(statsResponse.data);
        
        // Load recent partners
        const partnersResponse = await mockApiService.getPartners({ limit: 3 });
        setRecentPartners(partnersResponse.data);
        
        // Load recent consultants  
        const consultantsResponse = await mockApiService.getConsultants({ limit: 3 });
        setRecentConsultants(consultantsResponse.data);
        
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  const quickActions = [
    {
      title: 'إضافة شريك جديد',
      description: 'أضف شريك جديد إلى قائمة الشركاء',
      href: '/admin/partners/new',
      icon: Users,
      color: 'bg-blue-500'
    },
    {
      title: 'إضافة مستشار',
      description: 'أضف مستشار جديد إلى الفريق',
      href: '/admin/consultants/new', 
      icon: UserCheck,
      color: 'bg-green-500'
    },
    {
      title: 'تحديث المحتوى',
      description: 'تحديث محتوى صفحة حول تليواي',
      href: '/admin/about',
      icon: Activity,
      color: 'bg-purple-500'
    }
  ];

  return (
    <div className="space-y-8" dir="rtl">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">لوحة التحكم</h1>
          <p className="text-muted-foreground">
            مرحباً بك في لوحة تحكم تليواي - إدارة محتوى الموقع
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="gap-1">
            <Clock className="w-3 h-3" />
            آخر تحديث: {stats && new Date(stats.lastUpdate).toLocaleString('ar-SA')}
          </Badge>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/30 border-blue-200 dark:border-blue-800">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium text-blue-700 dark:text-blue-300">
              إجمالي الشركاء
            </CardTitle>
            <Users className="h-4 w-4 text-blue-600 dark:text-blue-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">
              {stats?.totalPartners || 0}
            </div>
            <p className="text-xs text-blue-600 dark:text-blue-400 flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" />
              نشط ومتاح
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/30 dark:to-green-900/30 border-green-200 dark:border-green-800">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium text-green-700 dark:text-green-300">
              المستشارون
            </CardTitle>
            <UserCheck className="h-4 w-4 text-green-600 dark:text-green-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-900 dark:text-green-100">
              {stats?.totalConsultants || 0}
            </div>
            <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" />
              خبراء متاحون
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-950/30 dark:to-purple-900/30 border-purple-200 dark:border-purple-800">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium text-purple-700 dark:text-purple-300">
              المستخدمون النشطون
            </CardTitle>
            <Activity className="h-4 w-4 text-purple-600 dark:text-purple-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-900 dark:text-purple-100">
              {stats?.activeUsers || 0}
            </div>
            <p className="text-xs text-purple-600 dark:text-purple-400 flex items-center gap-1 mt-1">
              <TrendingUp className="w-3 h-3" />
              متصلون الآن
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-950/30 dark:to-orange-900/30 border-orange-200 dark:border-orange-800">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-sm font-medium text-orange-700 dark:text-orange-300">
              آخر نشاط
            </CardTitle>
            <Calendar className="h-4 w-4 text-orange-600 dark:text-orange-400" />
          </CardHeader>
          <CardContent>
            <div className="text-sm font-bold text-orange-900 dark:text-orange-100">
              اليوم
            </div>
            <p className="text-xs text-orange-600 dark:text-orange-400 flex items-center gap-1 mt-1">
              <Clock className="w-3 h-3" />
              تم التحديث مؤخراً
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-semibold mb-4">الإجراءات السريعة</h2>
        <div className="grid gap-4 md:grid-cols-3">
          {quickActions.map((action, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer group">
              <CardContent className="p-6">
                <Link to={action.href} className="block">
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-lg ${action.color} bg-opacity-10`}>
                      <action.icon className={`h-6 w-6 ${action.color.replace('bg-', 'text-')}`} />
                    </div>
                    <div className="flex-1 space-y-1">
                      <h3 className="font-medium group-hover:text-primary transition-colors">
                        {action.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {action.description}
                      </p>
                    </div>
                    <Plus className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent Items */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Partners */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">الشركاء الأخيرون</CardTitle>
              <CardDescription>آخر الشركاء المضافين</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/admin/partners">
                <Eye className="w-4 h-4 ml-1" />
                عرض الكل
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentPartners.map((partner) => (
              <div key={partner.id} className="flex items-center gap-4 p-3 rounded-lg border bg-card/50">
                <div 
                  className="w-12 h-12 rounded-lg flex items-center justify-center text-white font-bold text-sm"
                  style={{ 
                    background: `linear-gradient(135deg, ${partner.colorFrom}, ${partner.colorTo})` 
                  }}
                >
                  {partner.name.substring(0, 2)}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">{partner.name}</h4>
                  <p className="text-sm text-muted-foreground">{partner.title}</p>
                </div>
                <Badge variant={partner.isActive ? "default" : "secondary"}>
                  {partner.isActive ? "نشط" : "غير نشط"}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Recent Consultants */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-lg">المستشارون الأخيرون</CardTitle>
              <CardDescription>آخر المستشارين المضافين</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link to="/admin/consultants">
                <Eye className="w-4 h-4 ml-1" />
                عرض الكل
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentConsultants.map((consultant) => (
              <div key={consultant.id} className="flex items-center gap-4 p-3 rounded-lg border bg-card/50">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-sm"
                  style={{ backgroundColor: consultant.backgroundColor }}
                >
                  {consultant.initials}
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">{consultant.name}</h4>
                  <p className="text-sm text-muted-foreground">{consultant.title}</p>
                </div>
                <Badge variant={consultant.isActive ? "default" : "secondary"}>
                  {consultant.isActive ? "نشط" : "غير نشط"}
                </Badge>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

// Loading skeleton component
const DashboardSkeleton: React.FC = () => (
  <div className="space-y-8" dir="rtl">
    <div>
      <Skeleton className="h-8 w-48 mb-2" />
      <Skeleton className="h-4 w-96" />
    </div>
    
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
      {Array.from({ length: 4 }).map((_, i) => (
        <Card key={i}>
          <CardHeader>
            <Skeleton className="h-4 w-24" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-8 w-16 mb-2" />
            <Skeleton className="h-3 w-20" />
          </CardContent>
        </Card>
      ))}
    </div>
    
    <div className="grid gap-4 md:grid-cols-3">
      {Array.from({ length: 3 }).map((_, i) => (
        <Card key={i}>
          <CardContent className="p-6">
            <Skeleton className="h-16 w-full" />
          </CardContent>
        </Card>
      ))}
    </div>
  </div>
);

export default Dashboard;