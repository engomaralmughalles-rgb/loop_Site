import React, { useState } from 'react';
import { Save, Eye, Upload, Image as ImageIcon, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';

interface AboutContent {
  title: string;
  subtitle: string;
  mainContent: string;
  heroImage: string;
  sections: {
    id: string;
    title: string;
    content: string;
    image?: string;
  }[];
}

const About: React.FC = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('edit');
  
  const [aboutContent, setAboutContent] = useState<AboutContent>({
    title: 'حول تليواي',
    subtitle: 'رواد الحلول التقنية في المملكة العربية السعودية',
    mainContent: 'تليواي هي شركة رائدة في مجال الحلول التقنية والاتصالات في المملكة العربية السعودية. تأسست الشركة بهدف تقديم أحدث التقنيات وأفضل الحلول لعملائنا في مختلف القطاعات.\n\nنحن نفخر بكوننا الشريك المفضل للعديد من الشركات الكبرى في المملكة، ونسعى دائماً لتقديم خدمات متميزة تلبي احتياجات عملائنا وتفوق توقعاتهم.',
    heroImage: '/src/assets/hero-bg.jpg',
    sections: [
      {
        id: '1',
        title: 'رؤيتنا',
        content: 'أن نكون الشركة الرائدة في تقديم الحلول التقنية المبتكرة والمتطورة في منطقة الشرق الأوسط.',
      },
      {
        id: '2',
        title: 'رسالتنا',
        content: 'تقديم حلول تقنية متميزة ومبتكرة تساهم في تطوير الأعمال وتحقيق النجاح لعملائنا من خلال فريق عمل محترف وخبرات متراكمة.',
      },
      {
        id: '3',
        title: 'قيمنا',
        content: 'الجودة، الابتكار، الشفافية، والالتزام بتقديم أفضل الخدمات لعملائنا.',
      },
    ],
  });

  const handleSave = () => {
    // Here you would typically save to your API
    toast({
      title: "تم الحفظ بنجاح",
      description: "تم حفظ التحديثات على محتوى صفحة حول تليواي",
    });
  };

  const handleSectionUpdate = (sectionId: string, field: string, value: string) => {
    setAboutContent(prev => ({
      ...prev,
      sections: prev.sections.map(section =>
        section.id === sectionId
          ? { ...section, [field]: value }
          : section
      ),
    }));
  };

  const addNewSection = () => {
    const newSection = {
      id: Date.now().toString(),
      title: 'قسم جديد',
      content: 'محتوى القسم الجديد...',
    };
    setAboutContent(prev => ({
      ...prev,
      sections: [...prev.sections, newSection],
    }));
  };

  const removeSection = (sectionId: string) => {
    setAboutContent(prev => ({
      ...prev,
      sections: prev.sections.filter(section => section.id !== sectionId),
    }));
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة محتوى حول تليواي</h1>
          <p className="text-muted-foreground mt-2">
            تحديث وإدارة محتوى صفحة حول الشركة
          </p>
        </div>
        <Button onClick={handleSave} className="gap-2">
          <Save className="w-4 h-4" />
          حفظ التغييرات
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="edit">تحرير المحتوى</TabsTrigger>
          <TabsTrigger value="preview">معاينة</TabsTrigger>
        </TabsList>
        
        <TabsContent value="edit" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>المحتوى الأساسي</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">العنوان الرئيسي</Label>
                <Input
                  id="title"
                  value={aboutContent.title}
                  onChange={(e) => setAboutContent({...aboutContent, title: e.target.value})}
                  placeholder="العنوان الرئيسي"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="subtitle">العنوان الفرعي</Label>
                <Input
                  id="subtitle"
                  value={aboutContent.subtitle}
                  onChange={(e) => setAboutContent({...aboutContent, subtitle: e.target.value})}
                  placeholder="العنوان الفرعي"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="mainContent">المحتوى الرئيسي</Label>
                <Textarea
                  id="mainContent"
                  value={aboutContent.mainContent}
                  onChange={(e) => setAboutContent({...aboutContent, mainContent: e.target.value})}
                  rows={8}
                  placeholder="المحتوى الرئيسي للصفحة"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="heroImage">صورة الخلفية</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="heroImage"
                    value={aboutContent.heroImage}
                    onChange={(e) => setAboutContent({...aboutContent, heroImage: e.target.value})}
                    placeholder="رابط الصورة"
                  />
                  <Button variant="outline" size="icon">
                    <Upload className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>الأقسام الفرعية</CardTitle>
                <Button onClick={addNewSection} variant="outline" size="sm" className="gap-2">
                  <Plus className="w-4 h-4" />
                  إضافة قسم
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {aboutContent.sections.map((section, index) => (
                <Card key={section.id} className="border-2 border-dashed">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Label className="text-sm font-medium">القسم {index + 1}</Label>
                      <Button
                        onClick={() => removeSection(section.id)}
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive"
                      >
                        حذف
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label>عنوان القسم</Label>
                      <Input
                        value={section.title}
                        onChange={(e) => handleSectionUpdate(section.id, 'title', e.target.value)}
                        placeholder="عنوان القسم"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>محتوى القسم</Label>
                      <Textarea
                        value={section.content}
                        onChange={(e) => handleSectionUpdate(section.id, 'content', e.target.value)}
                        rows={4}
                        placeholder="محتوى القسم"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>صورة القسم (اختيارية)</Label>
                      <div className="flex items-center gap-2">
                        <Input
                          value={section.image || ''}
                          onChange={(e) => handleSectionUpdate(section.id, 'image', e.target.value)}
                          placeholder="رابط صورة القسم"
                        />
                        <Button variant="outline" size="icon">
                          <ImageIcon className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="preview" className="space-y-6">
          <Card>
            <CardContent className="p-0">
              <div className="relative h-64 bg-gradient-to-r from-primary to-primary/80 text-white overflow-hidden rounded-t-lg">
                <div className="absolute inset-0 bg-black/20"></div>
                <div className="relative z-10 p-8 h-full flex flex-col justify-center">
                  <h1 className="text-4xl font-bold mb-4">{aboutContent.title}</h1>
                  <p className="text-xl opacity-90">{aboutContent.subtitle}</p>
                </div>
              </div>
              
              <div className="p-8">
                <div className="prose max-w-none text-right">
                  {aboutContent.mainContent.split('\n').map((paragraph, index) => (
                    <p key={index} className="mb-4 text-muted-foreground leading-relaxed">
                      {paragraph}
                    </p>
                  ))}
                </div>
                
                <div className="grid gap-8 mt-12 md:grid-cols-2 lg:grid-cols-3">
                  {aboutContent.sections.map((section) => (
                    <Card key={section.id} className="border-none shadow-md">
                      <CardContent className="p-6">
                        <h3 className="text-xl font-semibold mb-4 text-primary">
                          {section.title}
                        </h3>
                        <p className="text-muted-foreground leading-relaxed">
                          {section.content}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default About;