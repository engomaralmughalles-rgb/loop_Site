import React, { useState } from 'react';
import { Plus, Search, Edit, Trash2, User, Mail, Phone, Linkedin, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';

interface SocialLink {
  platform: string;
  url: string;
  icon: string;
}

interface Consultant {
  id: string;
  name: string;
  title: string;
  description: string;
  email: string;
  phone: string;
  avatar?: string;
  isActive: boolean;
  socialLinks: SocialLink[];
  createdAt: Date;
}

const Consultants: React.FC = () => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingConsultant, setEditingConsultant] = useState<Consultant | null>(null);
  
  const [consultants, setConsultants] = useState<Consultant[]>([
    {
      id: '1',
      name: 'د. أحمد محمد الشهري',
      title: 'مستشار أول - حلول الاتصالات',
      description: 'خبير في تقنيات الاتصالات مع أكثر من 15 عام من الخبرة',
      email: 'ahmed.alshehri@teleway.com.sa',
      phone: '+966501234567',
      avatar: '/src/assets/dr-ahmed.jpg',
      isActive: true,
      socialLinks: [
        { platform: 'LinkedIn', url: 'https://linkedin.com/in/ahmed-alshehri', icon: 'linkedin' },
        { platform: 'Website', url: 'https://ahmed-alshehri.com', icon: 'globe' }
      ],
      createdAt: new Date('2024-01-10'),
    },
    {
      id: '2',
      name: 'م. فاطمة علي القحطاني',
      title: 'مستشارة تقنية - الشبكات',
      description: 'متخصصة في تصميم وإدارة الشبكات الذكية',
      email: 'fatima.alqahtani@teleway.com.sa',
      phone: '+966507654321',
      isActive: true,
      socialLinks: [
        { platform: 'LinkedIn', url: 'https://linkedin.com/in/fatima-alqahtani', icon: 'linkedin' }
      ],
      createdAt: new Date('2024-02-15'),
    },
  ]);

  const [formData, setFormData] = useState({
    name: '',
    title: '',
    description: '',
    email: '',
    phone: '',
    isActive: true,
  });

  const filteredConsultants = consultants.filter(consultant =>
    consultant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    consultant.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleEdit = (consultant: Consultant) => {
    setEditingConsultant(consultant);
    setFormData({
      name: consultant.name,
      title: consultant.title,
      description: consultant.description,
      email: consultant.email,
      phone: consultant.phone,
      isActive: consultant.isActive,
    });
    setIsDialogOpen(true);
  };

  const handleDelete = (id: string) => {
    setConsultants(consultants.filter(c => c.id !== id));
    toast({
      title: "تم حذف المستشار",
      description: "تم حذف المستشار بنجاح",
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingConsultant) {
      setConsultants(consultants.map(c => 
        c.id === editingConsultant.id 
          ? { ...c, ...formData }
          : c
      ));
      toast({
        title: "تم تحديث المستشار",
        description: "تم تحديث بيانات المستشار بنجاح",
      });
    } else {
      const newConsultant: Consultant = {
        id: Date.now().toString(),
        ...formData,
        socialLinks: [],
        createdAt: new Date(),
      };
      setConsultants([...consultants, newConsultant]);
      toast({
        title: "تم إضافة مستشار جديد",
        description: "تم إضافة المستشار الجديد بنجاح",
      });
    }
    
    setIsDialogOpen(false);
    setEditingConsultant(null);
    setFormData({ name: '', title: '', description: '', email: '', phone: '', isActive: true });
  };

  const openCreateDialog = () => {
    setEditingConsultant(null);
    setFormData({ name: '', title: '', description: '', email: '', phone: '', isActive: true });
    setIsDialogOpen(true);
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  return (
    <div className="space-y-6" dir="rtl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">إدارة المستشارين</h1>
          <p className="text-muted-foreground mt-2">
            إدارة فريق المستشارين وخبراء تليواي
          </p>
        </div>
        
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog} className="gap-2">
              <Plus className="w-4 h-4" />
              إضافة مستشار جديد
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md" dir="rtl">
            <DialogHeader>
              <DialogTitle>
                {editingConsultant ? 'تحديث بيانات المستشار' : 'إضافة مستشار جديد'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">الاسم الكامل</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="أدخل الاسم الكامل"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="title">المنصب</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  placeholder="أدخل المنصب أو التخصص"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">نبذة تعريفية</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="أدخل نبذة تعريفية عن المستشار"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">البريد الإلكتروني</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  placeholder="email@teleway.com.sa"
                  required
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone">رقم الهاتف</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  placeholder="+966501234567"
                />
              </div>
              
              <div className="flex items-center justify-between">
                <Label htmlFor="isActive">نشط</Label>
                <Switch
                  id="isActive"
                  checked={formData.isActive}
                  onCheckedChange={(checked) => setFormData({...formData, isActive: checked})}
                />
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1">
                  {editingConsultant ? 'تحديث' : 'إضافة'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                  className="flex-1"
                >
                  إلغاء
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>قائمة المستشارين ({consultants.length})</CardTitle>
            <div className="relative w-72">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input
                placeholder="البحث في المستشارين..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 text-right"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredConsultants.map((consultant) => (
              <Card key={consultant.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-16 h-16">
                      <AvatarImage src={consultant.avatar} alt={consultant.name} />
                      <AvatarFallback className="text-lg font-semibold">
                        {getInitials(consultant.name)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-lg leading-tight">{consultant.name}</h3>
                          <p className="text-sm text-muted-foreground">{consultant.title}</p>
                        </div>
                        <Badge variant={consultant.isActive ? "default" : "secondary"} className="text-xs">
                          {consultant.isActive ? 'نشط' : 'غير نشط'}
                        </Badge>
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                        {consultant.description}
                      </p>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2 text-sm">
                          <Mail className="w-4 h-4 text-muted-foreground" />
                          <span className="truncate">{consultant.email}</span>
                        </div>
                        {consultant.phone && (
                          <div className="flex items-center gap-2 text-sm">
                            <Phone className="w-4 h-4 text-muted-foreground" />
                            <span>{consultant.phone}</span>
                          </div>
                        )}
                      </div>
                      
                      {consultant.socialLinks.length > 0 && (
                        <div className="flex items-center gap-2 mb-4">
                          {consultant.socialLinks.map((link, index) => (
                            <Button
                              key={index}
                              variant="ghost"
                              size="icon"
                              className="w-8 h-8"
                              asChild
                            >
                              <a href={link.url} target="_blank" rel="noopener noreferrer">
                                {link.icon === 'linkedin' ? <Linkedin className="w-4 h-4" /> : <Globe className="w-4 h-4" />}
                              </a>
                            </Button>
                          ))}
                        </div>
                      )}
                      
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(consultant)}
                          className="flex-1"
                        >
                          <Edit className="w-4 h-4 ml-1" />
                          تحديث
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(consultant.id)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          {filteredConsultants.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">
              <User className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <p className="text-lg mb-2">لا توجد نتائج</p>
              <p className="text-sm">لم يتم العثور على مستشارين للبحث "{searchQuery}"</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Consultants;