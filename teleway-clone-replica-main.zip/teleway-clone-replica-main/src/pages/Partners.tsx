import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Partners = () => {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-blue-50 to-gray-100">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-30"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=1887&auto=format&fit=crop')`,
          }}
        />
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-loop-dark mb-4">
            Our Partners
          </h1>
          <nav className="flex justify-center items-center space-x-2 text-loop-gray">
            <a href="/" className="hover:text-loop-blue transition-colors">Home</a>
            <span>›</span>
            <span className="text-loop-blue">Our Partners</span>
          </nav>
        </div>
      </section>

      {/* Partners Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {/* STC */}
            <div className="bg-gradient-to-br from-purple-600 to-purple-800 rounded-2xl p-12 text-center shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="text-white">
                <h2 className="text-4xl font-bold mb-2">stc</h2>
                <p className="text-purple-200 text-sm">Saudi Telecom Company</p>
              </div>
            </div>

            {/* Zain */}
            <div className="bg-gradient-to-br from-green-500 to-green-700 rounded-2xl p-12 text-center shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="text-white">
                <h2 className="text-4xl font-bold mb-2" style={{ fontFamily: 'Arial, sans-serif' }}>
                  زين<br />
                  <span className="text-2xl font-normal">zain</span>
                </h2>
              </div>
            </div>

            {/* Mobily */}
            <div className="bg-gradient-to-br from-blue-500 to-blue-700 rounded-2xl p-12 text-center shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="text-white">
                <h2 className="text-3xl font-bold mb-2">
                  موبايلي<br />
                  <span className="text-2xl font-normal">Mobily</span>
                </h2>
              </div>
            </div>

            {/* Nokia */}
            <div className="bg-gradient-to-br from-blue-800 to-blue-900 rounded-2xl p-12 text-center shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-2 md:col-span-2 lg:col-span-1">
              <div className="text-white">
                <h2 className="text-4xl font-bold tracking-wider">NOKIA</h2>
                <p className="text-blue-300 text-sm mt-2">Connecting People</p>
              </div>
            </div>

            {/* Salam */}
            <div className="bg-gradient-to-br from-green-600 to-green-800 rounded-2xl p-12 text-center shadow-2xl hover:shadow-3xl transition-all duration-300 transform hover:-translate-y-2 md:col-span-1 lg:col-span-2">
              <div className="text-white relative">
                <div className="bg-green-500 rounded-full w-24 h-24 mx-auto flex items-center justify-center mb-4">
                  <h2 className="text-2xl font-bold">salam</h2>
                </div>
                <p className="text-green-200 text-sm">Telecom Solutions</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Help Section */}
      <section className="py-16 bg-gray-50 relative">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1887&auto=format&fit=crop')`,
          }}
        />
        <div className="relative container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto">
            <div className="bg-loop-blue text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <span className="text-2xl">?</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-loop-dark mb-6">
              We're Here To Help
            </h2>
            <p className="text-loop-gray text-lg mb-8 leading-relaxed">
              Businesses today cross borders and regions, so you need a service that goes where you are. 
              Our partnerships with leading telecom operators ensure comprehensive coverage and support across all regions.
            </p>
            <Button 
              className="bg-loop-blue hover:bg-blue-600 text-white px-8 py-4 text-lg font-semibold rounded-full transition-all duration-300 shadow-lg hover:shadow-xl"
              onClick={() => window.location.href = '/contact'}
            >
              Get help here
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Partners;