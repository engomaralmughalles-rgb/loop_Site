import { Button } from "@/components/ui/button";
import { Check, Hammer, Radio, Building2, Wifi, Network, Smartphone, Server } from "lucide-react";
import { useSEO } from "@/hooks/useSEO";

const OurProjects = () => {
  // SEO optimization
  useSEO({
    title: "مشاريعنا - شركة Loop | مشاريع الاتصالات والتكنولوجيا",
    description: "استكشف مشاريع Loop المتميزة في مجال الاتصالات والألياف البصرية. نقدم حلول متطورة لشبكات 5G والاتصالات الحرجة والبنية التحتية للاتصالات في السعودية.",
    keywords: "مشاريع Loop, الألياف البصرية, 5G, الاتصالات الحرجة, البنية التحتية, STC, Zain, Mobily, Nokia",
    canonicalUrl: `${window.location.origin}/our-projects`,
    ogUrl: window.location.href,
    structuredData: {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "مشاريعنا - Loop",
      "description": "تعرف على مشاريع Loop في مجال الاتصالات والتكنولوجيا",
      "url": `${window.location.origin}/our-projects`
    }
  });

  const projects = [
    {
      company: "STC",
      title: "Fiber Optics Sales & Installation",
      description: "Comprehensive fiber optics network deployment and sales operations for Saudi Telecom Company, covering residential and commercial sectors across the Kingdom.",
      features: [
        "FTTH (Fiber to the Home) installation and maintenance",
        "High-speed internet connectivity solutions",
        "24/7 technical support and customer service",
        "Network optimization and performance monitoring"
      ],
      icon: Wifi
    },
    {
      company: "Zain",
      title: "Corporate Sales & Services",
      description: "Enterprise-level telecommunications solutions and services for corporate clients, including dedicated connectivity and managed services.",
      features: [
        "Dedicated internet connectivity for businesses",
        "Managed network services and security solutions", 
        "VPN and cloud connectivity services",
        "Enterprise mobility and communication solutions"
      ],
      icon: Building2
    },
    {
      company: "Mobily",
      title: "Sales & FTTH Installation",
      description: "Complete fiber optic network deployment and sales operations, focusing on residential broadband services and infrastructure development.",
      features: [
        "Residential fiber optic installations",
        "High-speed broadband service activation",
        "Network infrastructure development",
        "Customer premises equipment installation"
      ],
      icon: Network
    },
    {
      company: "Nokia",
      title: "FTTH Installation and Maintenance",
      description: "Advanced fiber network installation and maintenance services using Nokia's cutting-edge technology and equipment.",
      features: [
        "Nokia equipment installation and configuration",
        "Network maintenance and troubleshooting",
        "Performance optimization and upgrades",
        "Technical training and knowledge transfer"
      ],
      icon: Server
    },
    {
      company: "SALAM",
      title: "FTTH and 5G Personal Sales & Services", 
      description: "Next-generation telecommunications services combining fiber optic and 5G technologies for enhanced connectivity and performance.",
      features: [
        "5G network deployment and optimization",
        "FTTH integration with 5G backhaul",
        "Advanced mobile connectivity solutions",
        "IoT and smart city infrastructure"
      ],
      icon: Smartphone
    }
  ];

  const futureProjects = {
    civilWork: [
      "Telecom towers supply and installation",
      "Site operation and maintenance services",
      "Civil and electromechanical engineering",
      "Infrastructure development and upgrades",
      "Environmental and safety compliance"
    ],
    criticalCommunication: [
      "HF/VHF Network supply and design",
      "Network element coding and configuration", 
      "Maintenance of communication systems",
      "Emergency communication solutions",
      "Mission-critical network reliability"
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1558494949-ef010cbdcc31?q=80&w=1934&auto=format&fit=crop')`,
          }}
        />
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4">
            Our Projects
          </h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Discover our portfolio of successful telecommunications projects and partnerships with leading operators
          </p>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Key Projects</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We partner with leading telecommunications operators to deliver cutting-edge solutions and infrastructure across Saudi Arabia.
            </p>
          </div>

          <div className="space-y-20">
            {projects.map((project, index) => {
              const IconComponent = project.icon;
              return (
                <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${
                  index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
                }`}>
                  <div className={`${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                    <div className="mb-6">
                      <h2 className="text-3xl font-bold text-loop-dark mb-2">{project.company}</h2>
                      <h3 className="text-xl font-semibold text-loop-blue mb-4">{project.title}</h3>
                    </div>
                    
                    <p className="text-gray-600 mb-6 leading-relaxed font-medium">
                      {project.description}
                    </p>
                    
                    {project.features.length > 0 && (
                      <ul className="space-y-3">
                        {project.features.map((feature, featureIndex) => (
                          <li key={featureIndex} className="flex items-start space-x-3">
                            <Check className="w-5 h-5 text-loop-blue mt-0.5 flex-shrink-0" />
                            <span className="text-gray-600">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                  
                  <div className={`${index % 2 === 1 ? 'lg:col-start-1' : ''}`}>
                    <div className="bg-white rounded-lg shadow-lg p-8 text-center">
                      <IconComponent className="w-24 h-24 text-loop-blue mx-auto mb-6" />
                      <h4 className="text-2xl font-bold text-loop-dark mb-2">{project.company}</h4>
                      <p className="text-loop-blue font-semibold">{project.title}</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Future Projects Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-loop-dark mb-4">Future Projects</h2>
            <p className="text-gray-600 text-lg">
              Loop has experienced staff who can support you in Telecom Projects in the following areas.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Civil Work */}
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="flex items-center mb-6">
                <Hammer className="w-8 h-8 text-loop-blue mr-4" />
                <h3 className="text-2xl font-bold text-loop-dark">CIVIL WORK</h3>
              </div>
              <ul className="space-y-4">
                {futureProjects.civilWork.map((item, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-loop-blue mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Critical Communication */}
            <div className="bg-gray-50 rounded-lg p-8">
              <div className="flex items-center mb-6">
                <Radio className="w-8 h-8 text-loop-blue mr-4" />
                <h3 className="text-2xl font-bold text-loop-dark">CRITICAL COMMUNICATION</h3>
              </div>
              <ul className="space-y-4">
                {futureProjects.criticalCommunication.map((item, index) => (
                  <li key={index} className="flex items-start space-x-3">
                    <Check className="w-5 h-5 text-loop-blue mt-0.5 flex-shrink-0" />
                    <span className="text-gray-600">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">We're Here To Help</h2>
          <p className="text-xl mb-8">Businesses today cross borders and regions, so you need</p>
          <Button 
            variant="hero"
            size="lg"
            onClick={() => window.location.href = '/contact'}
          >
            Get Help Here
          </Button>
        </div>
      </section>
    </div>
  );
};

export default OurProjects;