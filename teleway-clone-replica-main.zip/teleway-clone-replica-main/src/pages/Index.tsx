import { useEffect } from "react";
import HeroSection from "@/components/HeroSection";
import InnovationsSection from "@/components/InnovationsSection";
import ServicesSection from "@/components/ServicesSection";
import AboutSection from "@/components/AboutSection";
import PartnersSection from "@/components/PartnersSection";
import StrengthSection from "@/components/StrengthSection";
import { useSEO, seoConfigs } from "@/hooks/useSEO";

const Index = () => {
  // SEO optimization
  useSEO({
    ...seoConfigs.homepage,
    canonicalUrl: window.location.origin,
    ogUrl: window.location.href
  });

  return (
    <div className="min-h-screen">
      {/* Semantic HTML structure for better SEO */}      
      <main>
        {/* Hero section with proper heading hierarchy */}
        <HeroSection />
        
        {/* Services section */}
        <section aria-label="Our Services">
          <ServicesSection />
        </section>
        
        {/* Innovations section */}
        <section aria-label="Innovations">
          <InnovationsSection />
        </section>
        
        {/* About section */}
        <section aria-label="About Us">
          <AboutSection />
        </section>
        
        {/* Partners section */}
        <section aria-label="Our Partners">
          <PartnersSection />
        </section>
        
        {/* Strength section */}
        <section aria-label="Our Strengths">
          <StrengthSection />
        </section>
      </main>
    </div>
  );
};

export default Index;
