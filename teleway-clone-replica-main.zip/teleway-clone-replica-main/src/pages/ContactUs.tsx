import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, Clock, Send } from "lucide-react";
import { useSEO } from "@/hooks/useSEO";

const ContactUs = () => {
  // SEO optimization
  useSEO({
    title: "اتصل بنا - شركة Loop | خدمة عملاء متميزة",
    description: "تواصل مع فريق Loop المتخصص. نحن هنا لمساعدتك في جميع استفساراتك حول خدماتنا في مجال الاتصالات والتكنولوجيا. اتصل بنا اليوم!",
    keywords: "اتصل بنا, خدمة عملاء Loop, استفسارات, دعم فني, الاتصالات, المملكة العربية السعودية",
    canonicalUrl: `${window.location.origin}/contact-us`,
    ogUrl: window.location.href,
    structuredData: {
      "@context": "https://schema.org",
      "@type": "ContactPage",
      "name": "اتصل بنا - Loop",
      "description": "صفحة الاتصال بشركة Loop للحصول على المساعدة والدعم",
      "url": `${window.location.origin}/contact-us`
    }
  });

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="relative py-24 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1423666639041-f56000c27a9a?q=80&w=1887&auto=format&fit=crop')`,
          }}
        />
        <div className="relative container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-loop-dark mb-4">
            Contact Us
          </h1>
          <nav className="flex justify-center items-center space-x-2 text-loop-gray">
            <a href="/" className="hover:text-loop-blue transition-colors">Home</a>
            <span>›</span>
            <span className="text-loop-blue">Contact Us</span>
          </nav>
        </div>
      </section>

      {/* Contact Information Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Info */}
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-8">Get In Touch</h2>
              <p className="text-lg text-gray-600 mb-12">
                We'd love to hear from you. Send us a message and we'll respond as soon as possible.
              </p>
              
              <div className="space-y-8">
                {/* Address */}
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Address</h3>
                    <address className="not-italic">
                      <a 
                        href="https://maps.google.com/?q=Riyadh,+Saudi+Arabia" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-loop-gray hover:text-loop-blue transition-colors text-sm leading-relaxed block"
                      >
                        Riyadh, Saudi Arabia<br />
                        Kingdom of Saudi Arabia
                      </a>
                    </address>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-6 h-6 text-loop-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-loop-dark mb-2">Phone</h3>
                    <div className="space-y-1">
                      <a 
                        href="tel:+966123456789" 
                        className="text-loop-gray hover:text-loop-blue transition-colors block"
                      >
                        +966 12 345 6789
                      </a>
                      <a 
                        href="tel:+966123456790" 
                        className="text-loop-gray hover:text-loop-blue transition-colors block"
                      >
                        +966 12 345 6790
                      </a>
                    </div>
                  </div>
                </div>

                {/* Email */}
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-6 h-6 text-loop-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-loop-dark mb-2">Email</h3>
                    <a 
                      href="mailto:info@loop-sa.com" 
                      className="text-loop-gray hover:text-loop-blue transition-colors text-sm"
                    >
                      info@loop-sa.com
                    </a>
                  </div>
                </div>

                {/* PO Box */}
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-6 h-6 text-loop-blue" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-loop-dark mb-2">PO Box</h3>
                    <p className="text-loop-gray text-sm leading-relaxed">
                      P.O. Box 12345<br />
                      Riyadh 11543<br />
                      Saudi Arabia
                    </p>
                  </div>
                </div>

                {/* Business Hours */}
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Clock className="w-6 h-6 text-indigo-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">Business Hours</h3>
                    <div className="text-gray-600 text-sm space-y-1">
                      <p>Sunday - Thursday: 8:00 AM - 6:00 PM</p>
                      <p>Friday - Saturday: Closed</p>
                      <p className="text-blue-600 font-medium">24/7 Emergency Support Available</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="flex items-center mb-6">
                <Send className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <h2 className="text-3xl font-bold text-loop-dark mb-4">Contact Form</h2>
                  <p className="text-loop-gray">
                    Ready to get started? Fill out the form below and we'll get back to you within 24 hours.
                  </p>
                </div>
              </div>
              
              <form className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      id="firstName"
                      name="firstName"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                      placeholder="Your first name"
                    />
                  </div>
                  <div>
                    <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      id="lastName"
                      name="lastName"
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                      placeholder="Your last name"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="your.email@example.com"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="+966 XX XXX XXXX"
                  />
                </div>

                <div>
                  <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                    Subject *
                  </label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
                    placeholder="How can we help you?"
                  />
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={6}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors resize-vertical"
                    placeholder="Please describe your inquiry in detail..."
                  ></textarea>
                </div>

                <Button 
                  type="submit"
                  variant="solid"
                  size="lg"
                  className="w-full"
                >
                  Send Message
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Find Us</h2>
            <p className="text-lg text-gray-600">
              Visit our office or get directions to our location
            </p>
          </div>
          
          <div className="relative h-96 rounded-xl overflow-hidden shadow-lg">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3624.091972439897!2d46.67184831498208!3d24.713552984142535!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e2ee2b8e6f6b9a5%3A0x1234567890123456!2sRiyadh%2C%20Saudi%20Arabia!5e0!3m2!1sen!2sus!4v1620000000000!5m2!1sen!2sus"
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen 
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Loop Office Location - Riyadh, Saudi Arabia"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactUs;