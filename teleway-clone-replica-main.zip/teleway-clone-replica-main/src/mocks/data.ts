import { Partner, Consultant, AboutContent, MissionVision, ContactInfo, User } from '@/types';

export const mockUser: User = {
  id: '1',
  email: 'admin@loop-sa.com',
  name: 'Admin User',
  role: 'admin',
  avatar: undefined
};

export const mockPartners: Partner[] = [
  {
    id: '1',
    name: 'STC',
    title: 'Fiber Optics Sales',
    description: 'STC Fiber Optics is the new home broadband service from STC.',
    colorFrom: 'rgb(147, 51, 234)', // purple-600
    colorTo: 'rgb(126, 34, 206)', // purple-700
    order: 1,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '2',
    name: 'Zain',
    title: 'Cooperate Sales & Services',
    description: 'Connectivity solutions to manage your business easily.',
    colorFrom: 'rgb(34, 197, 94)', // green-500
    colorTo: 'rgb(22, 163, 74)', // green-600
    order: 2,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '3',
    name: 'Mobily',
    title: 'Sales & FTTH Installation',
    description: 'Mobily Fiber Optics is the new home broadband service from Mobily.',
    colorFrom: 'rgb(249, 115, 22)', // orange-500
    colorTo: 'rgb(234, 88, 12)', // orange-600
    order: 3,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '4',
    name: 'Nokia',
    title: 'FTTH Installation and Maintenance',
    description: 'Nokia already powers the most powerful and reliable fiber networks in the world.',
    colorFrom: 'rgb(59, 130, 246)', // blue-500
    colorTo: 'rgb(37, 99, 235)', // blue-600
    order: 4,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '5',
    name: 'SALAM',
    title: 'FTTH and 5G Personal Sales & Services',
    description: 'FTTH & 5G higher performance and improved efficiency that 5G technology offers empower user experience.',
    colorFrom: 'rgb(239, 68, 68)', // red-500
    colorTo: 'rgb(220, 38, 38)', // red-600
    order: 5,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  }
];

export const mockConsultants: Consultant[] = [
  {
    id: '1',
    name: 'Engr. Mansour Al-Obaid',
    title: 'Group Consultant',
    initials: 'M.A',
    backgroundColor: 'rgb(59, 130, 246)', // blue-500
    socialLinks: [
      { id: '1', name: 'LinkedIn', url: 'https://linkedin.com', icon: 'linkedin' },
      { id: '2', name: 'Email', url: 'mailto:mansour@loop-sa.com', icon: 'mail' }
    ],
    order: 1,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '2',
    name: 'Bader Abdullah Bin Shaieg',
    title: 'Financial Advisory',
    initials: 'B.S',
    backgroundColor: 'rgb(34, 197, 94)', // green-500
    socialLinks: [
      { id: '3', name: 'LinkedIn', url: 'https://linkedin.com', icon: 'linkedin' }
    ],
    order: 2,
    isActive: true,
    createdAt: '2024-01-01T00:00:00Z',
    updatedAt: '2024-01-01T00:00:00Z'
  }
];

export const mockAbout: AboutContent = {
  id: '1',
  title: 'About Loop',
  subtitle: 'WHO WE ARE ?',
  content: 'Loop is adopting the philosophy of combining the telecom and the technology partnership with the service providers in order to propose the full service to customers.\n\nOur journey began in 2005, we evolved from pioneers in providing telecom operator services to individual clients to become expert system integrators, providing end-to-end fiber optics network and landline in various regions in the Kingdom. And we believe that there is no substitute for human capital, so our highly qualified, experienced, and dedicated teams are the driving force behind the transformation from a strategic vision, it was launched from Riyadh city, into a company with more than 350 employees, with branches in Jeddah and Al Khobar and we look forward to spreading our services to other cities in the Kingdom.',
  sections: [
    {
      id: '1',
      type: 'text',
      title: 'Our Philosophy',
      content: 'Combining telecom and technology partnership with service providers.',
      order: 1
    },
    {
      id: '2',
      type: 'text',
      title: 'Our Journey',
      content: 'Started in 2005, evolved from telecom operator services to expert system integrators.',
      order: 2
    }
  ],
  updatedAt: '2024-01-01T00:00:00Z'
};

export const mockMissionVision: MissionVision = {
  mission: {
    title: 'Mission',
    items: [
      { id: '1', text: 'Devices to provide network services', order: 1 },
      { id: '2', text: 'Installation and maintenance for fiber', order: 2 },
      { id: '3', text: 'Sales and marketing communication Products', order: 3 },
      { id: '4', text: 'Managed Services', order: 4 }
    ]
  },
  vision: {
    title: 'Vision',
    items: [
      { id: '1', text: 'Number one Telecom partner, for all operators in all segments', order: 1 },
      { id: '2', text: 'To enhance the internet of things awareness to our clients and partners', order: 2 }
    ]
  },
  updatedAt: '2024-01-01T00:00:00Z'
};

export const mockContactInfo: ContactInfo = {
  id: '1',
  address: 'Olaya Main Street, Al Muruj',
  city: 'Riyadh',
  postalCode: '12281',
  country: 'Saudi Arabia',
  phones: ['011 414 1413', '011 222 0319'],
  email: 'info@loop-sa.com',
  poBox: 'Riyadh – 12281, Saudi Arabia',
  mapUrl: 'https://maps.google.com/?q=Olaya+Main+Street,+Al+Muruj,+Riyadh',
  socialLinks: [
    { id: '1', name: 'Facebook', url: 'https://facebook.com/loop-sa', icon: 'facebook' },
    { id: '2', name: 'LinkedIn', url: 'https://linkedin.com/company/loop-sa', icon: 'linkedin' },
    { id: '3', name: 'Twitter', url: 'https://twitter.com/loop_sa', icon: 'twitter' },
    { id: '4', name: 'Instagram', url: 'https://instagram.com/loop_sa', icon: 'instagram' },
    { id: '5', name: 'YouTube', url: 'https://youtube.com/loop-sa', icon: 'youtube' }
  ],
  updatedAt: '2024-01-01T00:00:00Z'
};