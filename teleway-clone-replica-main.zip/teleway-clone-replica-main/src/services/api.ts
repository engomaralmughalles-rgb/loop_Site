import { 
  Partner, 
  Consultant, 
  AboutContent, 
  MissionVision, 
  ContactInfo, 
  User,
  ApiResponse,
  PaginatedResponse,
  SearchFilters,
  LoginCredentials,
  DashboardStats
} from '@/types';

// API Interface - replaceable with real backend later
export interface IApiService {
  // Authentication
  login(credentials: LoginCredentials): Promise<ApiResponse<{ user: User; token: string }>>;
  logout(): Promise<void>;
  getCurrentUser(): Promise<ApiResponse<User>>;

  // Partners
  getPartners(filters?: SearchFilters): Promise<PaginatedResponse<Partner>>;
  getPartner(id: string): Promise<ApiResponse<Partner>>;
  createPartner(partner: Omit<Partner, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Partner>>;
  updatePartner(id: string, partner: Partial<Partner>): Promise<ApiResponse<Partner>>;
  deletePartner(id: string): Promise<ApiResponse<void>>;
  reorderPartners(partners: { id: string; order: number }[]): Promise<ApiResponse<void>>;

  // Consultants
  getConsultants(filters?: SearchFilters): Promise<PaginatedResponse<Consultant>>;
  getConsultant(id: string): Promise<ApiResponse<Consultant>>;
  createConsultant(consultant: Omit<Consultant, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Consultant>>;
  updateConsultant(id: string, consultant: Partial<Consultant>): Promise<ApiResponse<Consultant>>;
  deleteConsultant(id: string): Promise<ApiResponse<void>>;
  reorderConsultants(consultants: { id: string; order: number }[]): Promise<ApiResponse<void>>;

  // Content Management
  getAbout(): Promise<ApiResponse<AboutContent>>;
  updateAbout(about: Partial<AboutContent>): Promise<ApiResponse<AboutContent>>;
  
  getMissionVision(): Promise<ApiResponse<MissionVision>>;
  updateMissionVision(missionVision: Partial<MissionVision>): Promise<ApiResponse<MissionVision>>;
  
  getContactInfo(): Promise<ApiResponse<ContactInfo>>;
  updateContactInfo(contactInfo: Partial<ContactInfo>): Promise<ApiResponse<ContactInfo>>;

  // File Upload (Mock)
  uploadFile(file: File, path: string): Promise<ApiResponse<{ url: string }>>;

  // Dashboard
  getDashboardStats(): Promise<ApiResponse<DashboardStats>>;
}

// Storage utilities
export const storage = {
  get: <T>(key: string): T | null => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch {
      return null;
    }
  },
  set: (key: string, value: any): void => {
    localStorage.setItem(key, JSON.stringify(value));
  },
  remove: (key: string): void => {
    localStorage.removeItem(key);
  },
  clear: (): void => {
    localStorage.clear();
  }
};

// Helper function to simulate API delay
export const delay = (ms: number = 500) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to generate IDs
export const generateId = () => Date.now().toString(36) + Math.random().toString(36).substr(2);

// Helper function to create API response
export const createResponse = <T>(data: T, message: string = 'Success'): ApiResponse<T> => ({
  data,
  message,
  success: true
});

// Helper function to create paginated response
export const createPaginatedResponse = <T>(
  data: T[], 
  page: number = 1, 
  limit: number = 10,
  total?: number
): PaginatedResponse<T> => {
  const actualTotal = total ?? data.length;
  return {
    data: data.slice((page - 1) * limit, page * limit),
    pagination: {
      page,
      limit,
      total: actualTotal,
      pages: Math.ceil(actualTotal / limit)
    }
  };
};