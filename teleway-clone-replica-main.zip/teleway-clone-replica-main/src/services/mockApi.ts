import { 
  IApiService,
  delay,
  generateId,
  createResponse,
  createPaginatedResponse,
  storage
} from './api';
import {
  mockPartners,
  mockConsultants,
  mockAbout,
  mockMissionVision,
  mockContactInfo,
  mockUser
} from '@/mocks/data';
import {
  Partner,
  Consultant,
  AboutContent,
  MissionVision,
  ContactInfo,
  User,
  ApiResponse,
  PaginatedResponse,
  SearchFilters,
  LoginCredentials,
  DashboardStats
} from '@/types';

// Storage keys
const STORAGE_KEYS = {
  AUTH_TOKEN: 'teleway_admin_token',
  AUTH_USER: 'teleway_admin_user',
  PARTNERS: 'teleway_partners',
  CONSULTANTS: 'teleway_consultants',
  ABOUT: 'teleway_about',
  MISSION_VISION: 'teleway_mission_vision',
  CONTACT_INFO: 'teleway_contact_info'
};

class MockApiService implements IApiService {
  
  constructor() {
    // Initialize mock data if not exists
    this.initializeMockData();
  }

  private initializeMockData() {
    if (!storage.get(STORAGE_KEYS.PARTNERS)) {
      storage.set(STORAGE_KEYS.PARTNERS, mockPartners);
    }
    if (!storage.get(STORAGE_KEYS.CONSULTANTS)) {
      storage.set(STORAGE_KEYS.CONSULTANTS, mockConsultants);
    }
    if (!storage.get(STORAGE_KEYS.ABOUT)) {
      storage.set(STORAGE_KEYS.ABOUT, mockAbout);
    }
    if (!storage.get(STORAGE_KEYS.MISSION_VISION)) {
      storage.set(STORAGE_KEYS.MISSION_VISION, mockMissionVision);
    }
    if (!storage.get(STORAGE_KEYS.CONTACT_INFO)) {
      storage.set(STORAGE_KEYS.CONTACT_INFO, mockContactInfo);
    }
  }

  // Authentication
  async login(credentials: LoginCredentials): Promise<ApiResponse<{ user: User; token: string }>> {
    await delay();
    
    // Mock authentication - simple check
    if (credentials.email === 'admin@teleway.com.sa' && credentials.password === 'admin123') {
      const token = generateId();
      const user = mockUser;
      
      storage.set(STORAGE_KEYS.AUTH_TOKEN, token);
      storage.set(STORAGE_KEYS.AUTH_USER, user);
      
      return createResponse({ user, token }, 'Login successful');
    }
    
    throw new Error('Invalid credentials');
  }

  async logout(): Promise<void> {
    await delay(200);
    storage.remove(STORAGE_KEYS.AUTH_TOKEN);
    storage.remove(STORAGE_KEYS.AUTH_USER);
  }

  async getCurrentUser(): Promise<ApiResponse<User>> {
    await delay(200);
    const user = storage.get<User>(STORAGE_KEYS.AUTH_USER);
    if (!user) throw new Error('No authenticated user');
    return createResponse(user);
  }

  // Partners
  async getPartners(filters?: SearchFilters): Promise<PaginatedResponse<Partner>> {
    await delay();
    let partners: Partner[] = storage.get(STORAGE_KEYS.PARTNERS) || [];
    
    // Apply filters
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      partners = partners.filter(p => 
        p.name.toLowerCase().includes(search) ||
        p.title.toLowerCase().includes(search) ||
        p.description.toLowerCase().includes(search)
      );
    }
    
    if (filters?.isActive !== undefined) {
      partners = partners.filter(p => p.isActive === filters.isActive);
    }

    // Sort
    if (filters?.sortBy) {
      partners.sort((a, b) => {
        const aVal = a[filters.sortBy as keyof Partner] as string;
        const bVal = b[filters.sortBy as keyof Partner] as string;
        const order = filters.sortOrder === 'desc' ? -1 : 1;
        return aVal.localeCompare(bVal) * order;
      });
    } else {
      partners.sort((a, b) => a.order - b.order);
    }

    return createPaginatedResponse(partners, filters?.page, filters?.limit);
  }

  async getPartner(id: string): Promise<ApiResponse<Partner>> {
    await delay();
    const partners: Partner[] = storage.get(STORAGE_KEYS.PARTNERS) || [];
    const partner = partners.find(p => p.id === id);
    if (!partner) throw new Error('Partner not found');
    return createResponse(partner);
  }

  async createPartner(partnerData: Omit<Partner, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Partner>> {
    await delay();
    const partners: Partner[] = storage.get(STORAGE_KEYS.PARTNERS) || [];
    
    const partner: Partner = {
      ...partnerData,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    partners.push(partner);
    storage.set(STORAGE_KEYS.PARTNERS, partners);
    
    return createResponse(partner, 'Partner created successfully');
  }

  async updatePartner(id: string, updates: Partial<Partner>): Promise<ApiResponse<Partner>> {
    await delay();
    const partners: Partner[] = storage.get(STORAGE_KEYS.PARTNERS) || [];
    const index = partners.findIndex(p => p.id === id);
    
    if (index === -1) throw new Error('Partner not found');
    
    partners[index] = {
      ...partners[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    storage.set(STORAGE_KEYS.PARTNERS, partners);
    return createResponse(partners[index], 'Partner updated successfully');
  }

  async deletePartner(id: string): Promise<ApiResponse<void>> {
    await delay();
    const partners: Partner[] = storage.get(STORAGE_KEYS.PARTNERS) || [];
    const filteredPartners = partners.filter(p => p.id !== id);
    
    if (partners.length === filteredPartners.length) {
      throw new Error('Partner not found');
    }
    
    storage.set(STORAGE_KEYS.PARTNERS, filteredPartners);
    return createResponse(undefined, 'Partner deleted successfully');
  }

  async reorderPartners(reorderedPartners: { id: string; order: number }[]): Promise<ApiResponse<void>> {
    await delay();
    const partners: Partner[] = storage.get(STORAGE_KEYS.PARTNERS) || [];
    
    reorderedPartners.forEach(({ id, order }) => {
      const partner = partners.find(p => p.id === id);
      if (partner) {
        partner.order = order;
        partner.updatedAt = new Date().toISOString();
      }
    });
    
    storage.set(STORAGE_KEYS.PARTNERS, partners);
    return createResponse(undefined, 'Partners reordered successfully');
  }

  // Consultants (similar pattern to Partners)
  async getConsultants(filters?: SearchFilters): Promise<PaginatedResponse<Consultant>> {
    await delay();
    let consultants: Consultant[] = storage.get(STORAGE_KEYS.CONSULTANTS) || [];
    
    if (filters?.search) {
      const search = filters.search.toLowerCase();
      consultants = consultants.filter(c => 
        c.name.toLowerCase().includes(search) ||
        c.title.toLowerCase().includes(search)
      );
    }
    
    if (filters?.isActive !== undefined) {
      consultants = consultants.filter(c => c.isActive === filters.isActive);
    }

    consultants.sort((a, b) => a.order - b.order);
    return createPaginatedResponse(consultants, filters?.page, filters?.limit);
  }

  async getConsultant(id: string): Promise<ApiResponse<Consultant>> {
    await delay();
    const consultants: Consultant[] = storage.get(STORAGE_KEYS.CONSULTANTS) || [];
    const consultant = consultants.find(c => c.id === id);
    if (!consultant) throw new Error('Consultant not found');
    return createResponse(consultant);
  }

  async createConsultant(consultantData: Omit<Consultant, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Consultant>> {
    await delay();
    const consultants: Consultant[] = storage.get(STORAGE_KEYS.CONSULTANTS) || [];
    
    const consultant: Consultant = {
      ...consultantData,
      id: generateId(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    consultants.push(consultant);
    storage.set(STORAGE_KEYS.CONSULTANTS, consultants);
    
    return createResponse(consultant, 'Consultant created successfully');
  }

  async updateConsultant(id: string, updates: Partial<Consultant>): Promise<ApiResponse<Consultant>> {
    await delay();
    const consultants: Consultant[] = storage.get(STORAGE_KEYS.CONSULTANTS) || [];
    const index = consultants.findIndex(c => c.id === id);
    
    if (index === -1) throw new Error('Consultant not found');
    
    consultants[index] = {
      ...consultants[index],
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    storage.set(STORAGE_KEYS.CONSULTANTS, consultants);
    return createResponse(consultants[index], 'Consultant updated successfully');
  }

  async deleteConsultant(id: string): Promise<ApiResponse<void>> {
    await delay();
    const consultants: Consultant[] = storage.get(STORAGE_KEYS.CONSULTANTS) || [];
    const filteredConsultants = consultants.filter(c => c.id !== id);
    
    if (consultants.length === filteredConsultants.length) {
      throw new Error('Consultant not found');
    }
    
    storage.set(STORAGE_KEYS.CONSULTANTS, filteredConsultants);
    return createResponse(undefined, 'Consultant deleted successfully');
  }

  async reorderConsultants(reorderedConsultants: { id: string; order: number }[]): Promise<ApiResponse<void>> {
    await delay();
    const consultants: Consultant[] = storage.get(STORAGE_KEYS.CONSULTANTS) || [];
    
    reorderedConsultants.forEach(({ id, order }) => {
      const consultant = consultants.find(c => c.id === id);
      if (consultant) {
        consultant.order = order;
        consultant.updatedAt = new Date().toISOString();
      }
    });
    
    storage.set(STORAGE_KEYS.CONSULTANTS, consultants);
    return createResponse(undefined, 'Consultants reordered successfully');
  }

  // Content Management
  async getAbout(): Promise<ApiResponse<AboutContent>> {
    await delay();
    const about = storage.get<AboutContent>(STORAGE_KEYS.ABOUT);
    if (!about) throw new Error('About content not found');
    return createResponse(about);
  }

  async updateAbout(updates: Partial<AboutContent>): Promise<ApiResponse<AboutContent>> {
    await delay();
    const about = storage.get<AboutContent>(STORAGE_KEYS.ABOUT);
    if (!about) throw new Error('About content not found');
    
    const updatedAbout = {
      ...about,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    storage.set(STORAGE_KEYS.ABOUT, updatedAbout);
    return createResponse(updatedAbout, 'About content updated successfully');
  }

  async getMissionVision(): Promise<ApiResponse<MissionVision>> {
    await delay();
    const missionVision = storage.get<MissionVision>(STORAGE_KEYS.MISSION_VISION);
    if (!missionVision) throw new Error('Mission & Vision not found');
    return createResponse(missionVision);
  }

  async updateMissionVision(updates: Partial<MissionVision>): Promise<ApiResponse<MissionVision>> {
    await delay();
    const missionVision = storage.get<MissionVision>(STORAGE_KEYS.MISSION_VISION);
    if (!missionVision) throw new Error('Mission & Vision not found');
    
    const updated = {
      ...missionVision,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    storage.set(STORAGE_KEYS.MISSION_VISION, updated);
    return createResponse(updated, 'Mission & Vision updated successfully');
  }

  async getContactInfo(): Promise<ApiResponse<ContactInfo>> {
    await delay();
    const contact = storage.get<ContactInfo>(STORAGE_KEYS.CONTACT_INFO);
    if (!contact) throw new Error('Contact info not found');
    return createResponse(contact);
  }

  async updateContactInfo(updates: Partial<ContactInfo>): Promise<ApiResponse<ContactInfo>> {
    await delay();
    const contact = storage.get<ContactInfo>(STORAGE_KEYS.CONTACT_INFO);
    if (!contact) throw new Error('Contact info not found');
    
    const updated = {
      ...contact,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    storage.set(STORAGE_KEYS.CONTACT_INFO, updated);
    return createResponse(updated, 'Contact info updated successfully');
  }

  // File Upload (Mock)
  async uploadFile(file: File): Promise<ApiResponse<{ url: string }>> {
    await delay(1000); // Simulate upload time
    
    // Convert file to Data URL for mock purposes
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        resolve(createResponse({ 
          url: reader.result as string 
        }, 'File uploaded successfully'));
      };
      reader.onerror = () => reject(new Error('File upload failed'));
      reader.readAsDataURL(file);
    });
  }

  // Dashboard Stats
  async getDashboardStats(): Promise<ApiResponse<DashboardStats>> {
    await delay();
    const partners = storage.get<Partner[]>(STORAGE_KEYS.PARTNERS) || [];
    const consultants = storage.get<Consultant[]>(STORAGE_KEYS.CONSULTANTS) || [];
    
    const stats: DashboardStats = {
      totalPartners: partners.length,
      totalConsultants: consultants.length,
      activeUsers: 1, // Mock value
      lastUpdate: new Date().toISOString()
    };
    
    return createResponse(stats);
  }
}

export const mockApiService = new MockApiService();