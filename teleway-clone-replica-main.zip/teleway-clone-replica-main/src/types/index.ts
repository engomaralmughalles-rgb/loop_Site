// Admin Dashboard Types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'editor';
  avatar?: string;
}

export interface Partner {
  id: string;
  name: string;
  title: string;
  description: string;
  colorFrom: string;
  colorTo: string;
  logo?: string;
  order: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Consultant {
  id: string;
  name: string;
  title: string;
  description?: string;
  initials: string;
  avatar?: string;
  backgroundColor: string;
  socialLinks: SocialLink[];
  order: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface SocialLink {
  id: string;
  name: string;
  url: string;
  icon: string;
}

export interface AboutContent {
  id: string;
  title: string;
  subtitle: string;
  content: string;
  heroImage?: string;
  sections: ContentSection[];
  updatedAt: string;
}

export interface ContentSection {
  id: string;
  type: 'text' | 'image' | 'list';
  title?: string;
  content: string;
  order: number;
}

export interface MissionItem {
  id: string;
  text: string;
  order: number;
}

export interface VisionItem {
  id: string;
  text: string;
  order: number;
}

export interface MissionVision {
  mission: {
    title: string;
    items: MissionItem[];
  };
  vision: {
    title: string;
    items: VisionItem[];
  };
  updatedAt: string;
}

export interface ContactInfo {
  id: string;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  phones: string[];
  email: string;
  poBox: string;
  mapUrl?: string;
  socialLinks: SocialLink[];
  updatedAt: string;
}

export interface DashboardStats {
  totalPartners: number;
  totalConsultants: number;
  activeUsers: number;
  lastUpdate: string;
}

// API Response types
export interface ApiResponse<T> {
  data: T;
  message: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    pages: number;
  };
}

// Filter and search types
export interface SearchFilters {
  search?: string;
  isActive?: boolean;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  page?: number;
  limit?: number;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

// SEO Management Types
export interface SEOSettings {
  id: string;
  pageName: string;
  pageSlug: string;
  title: string;
  description: string;
  keywords?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  twitterCard?: 'summary' | 'summary_large_image';
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface GlobalSEOSettings {
  siteName: string;
  siteDescription: string;
  defaultOgImage: string;
  twitterHandle: string;
  googleAnalyticsId?: string;
  googleTagManagerId?: string;
  facebookPixelId?: string;
  robots: string;
  updatedAt: string;
}