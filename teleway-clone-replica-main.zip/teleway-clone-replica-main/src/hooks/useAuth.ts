import { useState, useEffect, createContext, useContext } from 'react';
import { AuthState, LoginCredentials, User } from '@/types';
import { mockApiService } from '@/services/mockApi';
import { storage } from '@/services/api';
import { useToast } from '@/hooks/use-toast';

interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => Promise<void>;
  checkAuth: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType | null>(null);

export const useAuthState = (): AuthContextType => {
  const [state, setState] = useState<AuthState>({
    user: null,
    token: null,
    isAuthenticated: false,
    isLoading: true
  });

  const { toast } = useToast();

  const checkAuth = async () => {
    try {
      setState(prev => ({ ...prev, isLoading: true }));
      
      const token = storage.get<string>('teleway_admin_token');
      const user = storage.get<User>('teleway_admin_user');
      
      if (token && user) {
        // Verify token is still valid (in real app, this would be an API call)
        setState({
          user,
          token,
          isAuthenticated: true,
          isLoading: false
        });
      } else {
        setState({
          user: null,
          token: null,
          isAuthenticated: false,
          isLoading: false
        });
      }
    } catch (error) {
      setState({
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false
      });
    }
  };

  const login = async (credentials: LoginCredentials) => {
    try {
      setState(prev => ({ ...prev, isLoading: true }));
      
      const response = await mockApiService.login(credentials);
      const { user, token } = response.data;
      
      setState({
        user,
        token,
        isAuthenticated: true,
        isLoading: false
      });

      toast({
        title: 'تم تسجيل الدخول بنجاح',
        description: `مرحباً ${user.name}`
      });
    } catch (error) {
      setState(prev => ({
        ...prev,
        isLoading: false
      }));
      
      toast({
        title: 'خطأ في تسجيل الدخول',
        description: error instanceof Error ? error.message : 'حدث خطأ غير متوقع',
        variant: 'destructive'
      });
      throw error;
    }
  };

  const logout = async () => {
    try {
      await mockApiService.logout();
      setState({
        user: null,
        token: null,
        isAuthenticated: false,
        isLoading: false
      });

      toast({
        title: 'تم تسجيل الخروج',
        description: 'تم تسجيل الخروج بنجاح'
      });
    } catch (error) {
      toast({
        title: 'خطأ',
        description: 'حدث خطأ أثناء تسجيل الخروج',
        variant: 'destructive'
      });
    }
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return {
    ...state,
    login,
    logout,
    checkAuth
  };
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};