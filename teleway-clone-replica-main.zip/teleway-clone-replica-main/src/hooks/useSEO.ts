import { useEffect } from 'react';

export interface SEOData {
  title: string;
  description: string;
  keywords?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  ogUrl?: string;
  twitterCard?: 'summary' | 'summary_large_image';
  canonicalUrl?: string;
  structuredData?: any;
}

export const useSEO = (seoData: SEOData) => {
  useEffect(() => {
    // Update page title
    document.title = seoData.title;

    // Helper function to update meta tag
    const updateMetaTag = (name: string, content: string, property?: boolean) => {
      const selector = property ? `meta[property="${name}"]` : `meta[name="${name}"]`;
      let meta = document.querySelector(selector) as HTMLMetaElement;
      
      if (!meta) {
        meta = document.createElement('meta');
        if (property) {
          meta.setAttribute('property', name);
        } else {
          meta.setAttribute('name', name);
        }
        document.head.appendChild(meta);
      }
      meta.content = content;
    };

    // Update meta description
    updateMetaTag('description', seoData.description);

    // Update keywords if provided
    if (seoData.keywords) {
      updateMetaTag('keywords', seoData.keywords);
    }

    // Update Open Graph tags
    updateMetaTag('og:title', seoData.ogTitle || seoData.title, true);
    updateMetaTag('og:description', seoData.ogDescription || seoData.description, true);
    
    if (seoData.ogImage) {
      updateMetaTag('og:image', seoData.ogImage, true);
    }
    
    if (seoData.ogUrl) {
      updateMetaTag('og:url', seoData.ogUrl, true);
    }

    // Update Twitter tags
    updateMetaTag('twitter:card', seoData.twitterCard || 'summary_large_image');
    updateMetaTag('twitter:title', seoData.ogTitle || seoData.title);
    updateMetaTag('twitter:description', seoData.ogDescription || seoData.description);
    
    if (seoData.ogImage) {
      updateMetaTag('twitter:image', seoData.ogImage);
    }

    // Update canonical URL
    if (seoData.canonicalUrl) {
      let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
      if (!canonical) {
        canonical = document.createElement('link');
        canonical.rel = 'canonical';
        document.head.appendChild(canonical);
      }
      canonical.href = seoData.canonicalUrl;
    }

    // Add structured data
    if (seoData.structuredData) {
      let scriptTag = document.querySelector('#structured-data') as HTMLScriptElement;
      if (!scriptTag) {
        scriptTag = document.createElement('script');
        scriptTag.id = 'structured-data';
        scriptTag.type = 'application/ld+json';
        document.head.appendChild(scriptTag);
      }
      scriptTag.textContent = JSON.stringify(seoData.structuredData);
    }

  }, [seoData]);
};

// SEO configuration for different pages
export const seoConfigs = {
  homepage: {
    title: 'Loop - الشركة الرائدة في حلول الاتصالات بالمملكة العربية السعودية',
    description: 'شركة لوب الرائدة في مجال حلول الاتصالات بالمملكة العربية السعودية. نقدم خدمات متطورة بالشراكة مع STC وزين وموبايلي ونوكيا وسلام.',
    keywords: 'لوب, اتصالات, STC, زين, موبايلي, نوكيا, سلام, السعودية, حلول الاتصالات',
    ogImage: '/loop-og-image.jpg',
    structuredData: {
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Loop",
      "url": "https://loop.com.sa",
      "logo": "/loop-logo.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+966-11-414-1413",
        "contactType": "Customer Service",
        "areaServed": "SA",
        "availableLanguage": "Arabic"
      },
      "sameAs": [
        "https://twitter.com/loop_sa",
        "https://linkedin.com/company/loop"
      ]
    }
  },
  about: {
    title: 'من نحن - Loop | شركة الاتصالات الرائدة في المملكة',
    description: 'تعرف على رسالة ورؤية شركة لوب وفريق العمل المتخصص في مجال الاتصالات والتكنولوجيا بالمملكة العربية السعودية.',
    keywords: 'من نحن, لوب, رسالة الشركة, رؤية, فريق العمل, اتصالات السعودية'
  },
  partners: {
    title: 'شركاؤنا - Loop | شراكات استراتيجية في قطاع الاتصالات',
    description: 'شراكاتنا الاستراتيجية مع كبرى شركات الاتصالات: STC، زين، موبايلي، نوكيا، وسلام لتقديم أفضل الحلول التقنية.',
    keywords: 'شركاء لوب, STC, زين, موبايلي, نوكيا, سلام, شراكات اتصالات'
  },
  projects: {
    title: 'مشاريعنا - Loop | حلول مبتكرة في مجال الاتصالات',
    description: 'استعرض مشاريعنا المتطورة وحلولنا المبتكرة في مجال الاتصالات والتكنولوجيا لخدمة العملاء في المملكة العربية السعودية.',
    keywords: 'مشاريع لوب, حلول اتصالات, تكنولوجيا, مشاريع تقنية, السعودية'
  },
  contact: {
    title: 'تواصل معنا - Loop | خدمة عملاء متميزة',
    description: 'تواصل مع فريق خدمة العملاء المتخصص في شركة لوب. نحن هنا لمساعدتك وتقديم أفضل الحلول التقنية.',
    keywords: 'تواصل معنا, خدمة عملاء لوب, دعم فني, استفسارات, اتصالات السعودية'
  }
};